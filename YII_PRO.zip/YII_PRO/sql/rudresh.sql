-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 04, 2024 at 07:51 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rudresh`
--

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1718430588),
('m130524_201442_init', 1718430613),
('m190124_110200_add_verification_token_column_to_user_table', 1718430614);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `updated_At` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `category`, `price`, `image`, `status`, `updated_At`, `deleted_at`) VALUES
(1, 'Apple iPhone 13 Pro', 'The iPhone 13 Pro features a stunning Super Retina XDR display, A15 Bionic chip, Pro camera system with 12MP sensor, and all-day battery life.', 'Electronics', 999.99, 'uploads/Screenshot from 2024-04-23 09-55-48.png', 'Active', '2024-07-04 05:22:36', NULL),
(2, 'Samsung Galaxy S22 Ultra', 'Experience the ultimate in mobile technology with the Galaxy S22 Ultra. It boasts a powerful Exynos processor, 108MP camera, and a vibrant Dynamic AMOLED 2X display.', 'Electronics', 1199.99, 'uploads/zana-latif-Q_wD3keqG54-unsplash.jpg', 'Inactive', '2024-07-04 05:22:52', NULL),
(3, 'Sony PlayStation 5', 'Get ready for the next generation of gaming with the PlayStation 5. It features lightning-fast SSD storage, immersive 3D audio, and stunning 4K graphics.', 'Electronics', 499.99, 'uploads/pexels-walls-io-440716388-21405617.jpg', 'Active', '2024-07-04 04:36:07', NULL),
(4, 'Microsoft Xbox Series X', 'Enter the future of gaming with the Xbox Series X. It delivers 4K gaming, 120fps, and instant loading with its custom SSD.', 'Electronics', 599.99, 'uploads/404_error-h.png', 'Active', '2024-07-04 04:36:07', NULL),
(5, 'Canon EOS R5', 'Capture stunning photos and 8K video with the Canon EOS R5 mirrorless camera. It features a 45MP full-frame CMOS sensor and advanced Dual Pixel CMOS AF II.', 'Electronics', 3799.99, 'uploads/Screenshot from 2024-06-07 18-54-38.png', 'Active', '2024-07-04 04:36:07', NULL),
(6, 'DJI Mavic Air 2', 'Take your aerial photography to new heights with the DJI Mavic Air 2 drone. It offers 4K video at 60fps, 34 minutes of flight time, and intelligent shooting modes.', 'Electronics', 799.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(7, 'Apple MacBook Pro 16\"', 'Power through your work with the Apple MacBook Pro 16\". It features an M1 Pro chip, stunning Liquid Retina XDR display, and up to 21 hours of battery life.', 'Computers', 2399.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(8, 'Microsoft Surface Laptop Studio', 'Meet the Microsoft Surface Laptop Studio, designed for versatility and performance. It features a 14.4\" PixelSense touchscreen, NVIDIA RTX graphics, and up to 19 hours of battery life.', 'Computers', 1799.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(9, 'Samsung Odyssey G9 Gaming Monitor', 'Immerse yourself in gaming with the Samsung Odyssey G9. It offers a 49\" dual QHD display with 240Hz refresh rate, NVIDIA G-Sync compatibility, and 1000R curvature.', 'Computers', 1499.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(10, 'Bose QuietComfort 45 Headphones', 'Enjoy world-class noise cancellation and superior sound quality with the Bose QuietComfort 45 headphones. Perfect for work, travel, and relaxation.', 'Electronics', 329.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(11, 'Nintendo Switch OLED Model', 'Experience gaming in a new light with the Nintendo Switch OLED Model. It features a vibrant OLED screen, enhanced audio, and versatile play modes.', 'Electronics', 349.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(12, 'Apple Watch Series 7', 'Stay connected and track your health with the Apple Watch Series 7. It features a larger, always-on Retina display and advanced health monitoring.', 'Electronics', 399.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(13, 'Fitbit Charge 5', 'Achieve your fitness goals with the Fitbit Charge 5. It tracks your heart rate, sleep stages, and workouts, and offers built-in GPS for outdoor activities.', 'Electronics', 179.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(14, 'Sony WH-1000XM4 Wireless Headphones', 'Enjoy industry-leading noise cancellation and premium sound quality with the Sony WH-1000XM4 wireless headphones. Perfect for music and travel.', 'Electronics', 349.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(15, 'LG OLED C1 65\" 4K Smart TV', 'Experience cinematic visuals with the LG OLED C1 65\" 4K Smart TV. It features OLED technology, Dolby Vision IQ, and AI ThinQ for smart functionality.', 'Electronics', 1999.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(16, 'GoPro Hero 10 Black', 'Capture stunning 5.3K video and 23MP photos with the GoPro Hero 10 Black action camera. It offers HyperSmooth 4.0 stabilization and improved low-light performance.', 'Electronics', 499.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(17, 'Microsoft Surface Pro 8', 'Versatile and powerful, the Microsoft Surface Pro 8 adapts to your needs with a 13\" PixelSense touchscreen, Intel Core processor, and all-day battery life.', 'Computers', 1099.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(18, 'Razer Blade 15 Advanced Gaming Laptop', 'Take your gaming to the next level with the Razer Blade 15 Advanced Gaming Laptop. It features a 15.6\" QHD display, NVIDIA RTX graphics, and customizable RGB keyboard.', 'Computers', 2499.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(19, 'Samsung Galaxy Tab S8 Ultra', 'Experience productivity and entertainment with the Samsung Galaxy Tab S8 Ultra. It boasts a stunning 14.6\" Super AMOLED display, S Pen support, and powerful performance.', 'Electronics', 1049.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(20, 'Amazon Kindle Oasis', 'Immerse yourself in books with the Amazon Kindle Oasis. It features a 7\" high-resolution display, adjustable warm light, and waterproof design for reading anywhere.', 'Electronics', 299.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(21, 'Bose SoundLink Revolve+ Bluetooth Speaker', 'Enjoy deep, loud, and immersive sound with the Bose SoundLink Revolve+ Bluetooth speaker. It offers 360-degree coverage and up to 17 hours of battery life.', 'Electronics', 299.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(22, 'Logitech G Pro X Superlight Wireless Gaming Mouse', 'Dominate your gaming sessions with the Logitech G Pro X Superlight Wireless Gaming Mouse. It features HERO sensor technology and ultra-lightweight design for superior performance.', 'Computers', 149.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(23, 'Apple AirPods Pro', 'Immerse yourself in rich, high-quality sound with the Apple AirPods Pro. They feature active noise cancellation, Transparency mode, and customizable fit for all-day comfort.', 'Electronics', 249.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(24, 'Sony A7 IV Mirrorless Camera', 'Capture breathtaking photos and videos with the Sony A7 IV mirrorless camera. It features a 33MP full-frame sensor, advanced autofocus, and 4K video recording.', 'Electronics', 2499.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(25, 'Dell XPS 15 9510 Laptop', 'Experience power and performance with the Dell XPS 15 9510 laptop. It boasts a stunning 15.6\" 4K UHD+ InfinityEdge touchscreen, Intel Core processor, and NVIDIA graphics.', 'Computers', 1999.99, '', 'Active', '2024-07-04 04:36:07', NULL),
(53, ' fgdgzdfs', 'gsgsfgdt', '5teggxf', 344.00, 'uploads/Screenshot from 2024-04-23 09-55-48.png', 'Active', '2024-07-04 04:36:07', NULL),
(54, 'sftssf', 'xsgxgdgdsgsdg', 'sdgststt', 4325.00, 'uploads/Screenshot from 2024-04-19 20-48-54.png', 'Active', '2024-07-04 04:36:07', NULL),
(55, 'wrthsifuykfi', 'gkasgksgffg', 'hskfcgkfgkf', 78.00, 'uploads/Screenshot from 2024-04-23 09-55-48.png', 'Active', '2024-07-04 04:36:07', NULL),
(56, 'edqahiafkagt', 'ksgkasgdkgsk', 'sgkdagsfdkgafkkg', 1324.00, 'uploads/images.jpg', 'Active', '2024-07-04 04:36:07', NULL),
(57, 'festsfwe', 'efarffe', 'safegswfaf', 13.00, 'uploads/Screenshot from 2024-06-06 16-26-35.png', 'Active', '2024-07-04 04:36:07', NULL),
(58, 'asdrdwrtws', 'fgstsfgeg', 'gwsgw', 435.00, 'uploads/1.3MB.pdf', 'Active', '2024-07-04 04:54:08', '2024-07-03 23:24:08');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `enroll_number` varchar(6) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `attendance` decimal(5,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `enroll_number`, `first_name`, `last_name`, `gender`, `attendance`, `created_at`, `updated_at`) VALUES
(1, 'E1001', 'John', 'Doe', 'male', 340.25, '2023-01-15 05:00:00', '2024-06-26 12:00:11'),
(2, 'E1002', 'Jane', 'Smith', 'female', 355.75, '2023-01-16 04:15:00', '2023-01-16 04:15:00'),
(3, 'E1003', 'Michael', 'Johnson', 'male', 358.50, '2023-01-17 02:50:00', '2023-01-17 02:50:00'),
(4, 'E1004', 'Emily', 'Brown', 'female', 333.00, '2023-01-18 05:30:00', '2023-01-18 05:30:00'),
(5, 'E1005', 'William', 'Martinez', 'male', 337.20, '2023-01-19 08:45:00', '2023-01-19 08:45:00'),
(6, 'E1006', 'Sophia', 'Garcia', 'female', 360.80, '2023-01-20 08:00:00', '2023-01-20 08:00:00'),
(7, 'E1007', 'Daniel', 'Wilson', 'male', 348.90, '2023-01-21 07:15:00', '2023-01-21 07:15:00'),
(8, 'E1008', 'Olivia', 'Lopez', 'female', 342.70, '2023-01-22 04:30:00', '2023-01-22 04:30:00'),
(9, 'E1009', 'Matthew', 'Anderson', 'male', 344.10, '2023-01-23 03:15:00', '2023-01-23 03:15:00'),
(10, 'E1010', 'Emma', 'Thomas', 'female', 359.30, '2023-01-24 06:00:00', '2023-01-24 06:00:00'),
(11, 'E1011', 'James', 'White', 'male', 336.40, '2023-01-25 03:45:00', '2023-01-25 03:45:00'),
(12, 'E1012', 'Ava', 'Clark', 'female', 351.60, '2023-01-26 08:30:00', '2023-01-26 08:30:00'),
(13, 'E1013', 'David', 'Hill', 'male', 363.80, '2023-01-27 06:30:00', '2023-01-27 06:30:00'),
(14, 'E1014', 'Mia', 'Lewis', 'female', 353.20, '2023-01-28 05:00:00', '2023-01-28 05:00:00'),
(15, 'E1015', 'Benjamin', 'Walker', 'male', 350.00, '2023-01-29 02:30:00', '2023-01-29 02:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT 10,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `verification_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`, `verification_token`) VALUES
(15, 'Admin', 'LSPUM5AYNXbrAwzHH-E3gwTHmpUYSGpY', '$2y$13$CI9N4BqmygscU8OGL6OXhOIR2LS83rLmj.3.FVYTeqIJvUJ0i.zuW', NULL, 'admin@gmail.com', 10, 1719998856, 1719998903, 'z6cOenZLKUJq7LjOzb2YHSsZJSLgQM30_1719998856');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(50) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com'),
(2, 'Rudresh', '$2y$10$MT4gzgcRnNTJydlv0h9eru7H1SFxL4boEdl4YKVwO3bqx1UY97.VC', 'Rudresh@gmail.com'),
(3, 'sahil', '$2y$13$hAd.TzfBdoCbeaBwNpPa/u2RHmZ8q.00hh1FlU4Wv/TlPG5I.4HH6', 'sahil@gmail.com'),
(4, 'user', '$2y$10$ITaflRUe931XWxA/zNzfoe3fqsIPCZ5rC2cAOYcsMnJLreJ6RsMCG', 'user@gmail.com'),
(5, 'user1', 'password1', 'user1@example.com'),
(6, 'user10', 'password10', 'user10@example.com'),
(7, 'user11', 'password11', 'user11@example.com'),
(8, 'user12', 'password12', 'user12@example.com'),
(9, 'user13', 'password13', 'user13@example.com'),
(10, 'user14', 'password14', 'user14@example.com'),
(11, 'user15', 'password15', 'user15@example.com'),
(12, 'user2', 'password2', 'user2@example.com'),
(13, 'user3', 'password3', 'user3@example.com'),
(14, 'user4', 'password4', 'user4@example.com'),
(15, 'user5', 'password5', 'user5@example.com'),
(16, 'user6', 'password6', 'user6@example.com'),
(17, 'user7', 'password7', 'user7@example.com'),
(18, 'user8', 'password8', 'user8@example.com'),
(19, 'user9', 'password9', 'user9@example.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `enroll_number` (`enroll_number`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`,`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`),
  ADD UNIQUE KEY `email_3` (`email`),
  ADD KEY `id` (`id`),
  ADD KEY `username_2` (`username`),
  ADD KEY `username_3` (`username`);
ALTER TABLE `users` ADD FULLTEXT KEY `password` (`password`);
ALTER TABLE `users` ADD FULLTEXT KEY `password_2` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
