<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "student".
 *
 * @property int $id
 * @property string|null $enroll_number
 * @property string $first_name
 * @property string $last_name
 * @property float $attendance
 * @property string $created_at
 * @property string $updated_at
 */
class Student extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'student';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'first_name', 'last_name'], 'required'],
            [['id'], 'integer'],
            [['attendance'], 'number'],
            [['created_at', 'updated_at'], 'safe'],
            [['enroll_number'], 'string', 'max' => 6],
            [['first_name', 'last_name'], 'string', 'max' => 50],
            [['enroll_number'], 'unique'],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'enroll_number' => 'Enroll Number',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'attendance' => 'Attendance',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
        ];
    }

    /**
     * {@inheritdoc}
     * @return StudentQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new StudentQuery(get_called_class());
    }
}
