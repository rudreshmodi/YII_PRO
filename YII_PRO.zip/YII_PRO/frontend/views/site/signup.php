<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap5\ActiveForm $form */
/** @var \frontend\models\SignupForm $model */

use yii\bootstrap5\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Signup';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-signup col-lg-12 container-fluid">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Please fill out the following fields to signup:</p>

    <div class="row container-fluid">
        <div class="w-full col-lg-12 container-fluid">
            <?php $form = ActiveForm::begin(['id' => 'form-signup']); ?>

                <?= $form->field($model, 'username')->textInput(['autofocus' => true]) ?>
        </div>

        <div class="w-full col-lg-6 container-fluid">
                <?= $form->field($model, 'email') ?>
        </div>
                <div class="w-full col-lg-6">
                <?= $form->field($model, 'password')->passwordInput() ?>
                </div>
                <div class="w-full col-lg-12 container-fluid">
                <div class="form-group">
                    <?= Html::submitButton('Signup', ['class' => 'btn btn-primary px-20 py-20', 'name' => 'signup-button']) ?>
                </div>
                </div>
    </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
