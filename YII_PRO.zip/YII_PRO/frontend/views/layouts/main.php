<?php

/** @var \yii\web\View $this */
/** @var string $content */

use backend\assets\AppAsset;
use common\widgets\Alert;
use yii\bootstrap5\Breadcrumbs;
use yii\bootstrap5\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100 w-100">

<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>

<body class="d-flex flex-column h-100">
    <?php $this->beginBody() ?>
    <!-- Page Wrapper -->
    <div id="wrapper" class="d-flex" style="z-index: 99;">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar" style="z-index: 99;">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= Yii::$app->homeUrl ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Rudresh <sup>2.0</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= Yii::$app->homeUrl ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Manage Products:</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Product Management:</h6>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['product/create']) ?>">Create New Product</a>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['product/index']) ?>">View Product</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Manage Users:</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">User Management:</h6>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['users/create']) ?>">Create New User</a>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['users/index']) ?>">View Users</a>
                    </div>
                </div>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider">
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['site/login']) ?>">Login</a>
                        <?php if (Yii::$app->user->isGuest) : ?>
                            <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['site/signup']) ?>">Register</a>
                        <?php endif; ?>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['product/create']) ?>">Create Product</a>

                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
            <div class="sidebar-card d-none d-lg-flex">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="...">
                <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p>
                <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content">

            <!-- Topbar -->
            <?php
            NavBar::begin([

                'brandUrl' => Yii::$app->homeUrl,
                'options' => [
                    'class' => 'navbar navbar-expand text-dark bg-white topbar mb-4 fixed-top',
                    'style' => 'z-index:1;'
                ],
            ]);

            $menuItems = [
                ['label' => 'Home', 'url' => ['/site/index']],
                ['label' => 'About', 'url' => ['/site/about']],
                ['label' => 'Contact', 'url' => ['/site/contact']],
                ['label' => 'Products', 'url' => ['/product/index']],
            ];


            if (Yii::$app->user->isGuest) {
                $menuItems[] = ['label' => 'Signup', 'url' => ['/site/signup']];
            }

            echo Nav::widget([
                'options' => ['class' => 'navbar-nav ml-auto'],
                'items' => $menuItems,
            ]);

            echo '<ul class="navbar-nav ml-auto">';
            echo '<li class="nav-item dropdown no-arrow">';
            echo '<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
            echo '<span class="mr-2 d-none d-lg-inline text-gray-600 small">Welcome, ' . (Yii::$app->user->isGuest ? 'Guest' : Yii::$app->user->identity->username) . '!</span>';
            echo '<img class="img-profile rounded-circle" src="img/undraw_profile.svg">';
            echo '</a>';
            echo '<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">';
            ?>

            <a class="dropdown-item" href=" <?= Yii::$app->urlManager->createUrl(['profile/index']) ?>"><i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>Profile</a>;
            <?php
            echo '<div class="dropdown-divider"></div>';
            echo '<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">';
            if (Yii::$app->user->isGuest) {
                echo Html::a('<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Login', ['/site/login'], ['class' => 'btn login d-flex text-decoration-none']);
            } else {
                echo Html::beginForm(['/site/logout'], 'post', ['class' => 'p-0 m-0 d-flex'])
                    . Html::submitButton('<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout', ['class' => 'btn p-0 m-0 logout text-decoration-none'])
                    . Html::endForm();
            }
            echo '</a>';
            echo '</div>';
            echo '</li>';
            echo '</ul>';

            NavBar::end();
            ?>
            <!-- End of Topbar -->

            <!-- Main Content -->
            <main role="main" class="flex-shrink-0">
                <div class="container">
                    <?= Breadcrumbs::widget([
                        'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                    ]) ?>
                    <?= Alert::widget() ?>
                    <?= $content ?>
                </div>
            </main>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer my-20 bg-white fixed-bottom" style="z-index: -1;">
                <div class="container my-auto text-center">
                    <div class="copyright text-center m-auto">
                        <span>&copy; <?= date('Y') ?> Your Website</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <?php $this->endBody() ?>
</body>

</html>
<?php $this->endPage(); ?>
