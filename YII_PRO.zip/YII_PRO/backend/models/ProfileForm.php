<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use common\models\User;

class ProfileForm extends Model
{
    public $username;
    public $email;
    public $oldPassword;
    public $newPassword;
    public $confirmPassword;

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['username', 'email'], 'required'],
            ['email', 'email'],
            [['oldPassword', 'newPassword', 'confirmPassword'], 'required', 'on' => 'changePassword'],
            ['oldPassword', 'validatePassword', 'on' => 'changePassword'],
            ['newPassword', 'string', 'min' => 6],
            ['confirmPassword', 'compare', 'compareAttribute' => 'newPassword', 'message' => 'Passwords do not match.'],
        ];
    }

    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     */
    public function validatePassword($attribute, $params)
    {
        if (!$this->hasErrors()) {
            $user = $this->getUser();

            if (!$user || !$user->validatePassword($this->oldPassword)) {
                $this->addError($attribute, 'Incorrect password.');
            }
        }
    }

    /**
     * Loads user attributes into the model from the logged-in user.
     * @param User $user
     */
    public function loadFromUser($user)
    {
        $this->username = $user->username;
        $this->email = $user->email;
    }

    /**
     * Saves user attributes from the model back to the logged-in user.
     * @param User $user
     * @return bool whether the attributes are saved successfully.
     */
    public function saveToUser($user)
    {
        if ($this->validate()) {
            $user->username = $this->username;
            $user->email = $this->email;
            if (!empty($this->newPassword)) {
                $user->setPassword($this->newPassword);
            }
            return $user->save();
        }
        return false;
    }

    /**
     * Finds user by [[username]]
     *
     * @return User|null
     */
    protected function getUser()
    {
        return User::findByUsername(Yii::$app->user->identity->username);
    }
}
?>