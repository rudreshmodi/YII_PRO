<?php

namespace backend\models;

use Yii;
use yii\web\UploadedFile;

/**
 * This is the model class for table "{{%products}}".
 *
 * @property int $id
 * @property string $name
 * @property string|null $description
 * @property string|null $category
 * @property float $price
 * @property string $image
 * @property string $status
 */
class Products extends \yii\db\ActiveRecord
{

    /**
     * @var UploadedFile
     */
    public $imageFile; 

    const SCENARIO_SOFT_DELETE = 'soft_delete';

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%products}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'price', 'category'], 'required'],
            [['description','status'], 'string'],
            [['price'], 'number'],
            [['name', 'image'], 'string', 'max' => 255],
            [['category'], 'string', 'max' => 100],
            [['name'], 'unique'],
            [['imageFile'], 'file', 'extensions' => 'jpg, jpeg, png', 'maxSize' => 10 * 1024 * 1024, 'tooBig' => 'Limit is 10MB'],
        ];
    }

public function scenarios()
{
    return array_merge(parent::scenarios(), [
        self::SCENARIO_SOFT_DELETE => [],
        ]);
    }

     /**
     * Override delete method to perform soft delete.
     */
    public function delete()
    {
        $this->scenario = self::SCENARIO_SOFT_DELETE;
        $this->deleted_at = date('d-m-Y H:i:s');
        return $this->save(false, ['deleted_at']);
    }

    public function restore()
    {
        $this->scenario = self::SCENARIO_SOFT_DELETE;   
        $this->deleted_at = null;
        return $this->save(false, ['deleted_at']);
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'description' => 'Description',
            'category' => 'Category',
            'price' => 'Price',
            'image' => 'Image',
            'status' => 'Status',
        ];
    }

    /**
     * Uploads the image file and sets the image attribute.
     *
     * @return bool Whether the upload and save are successful.
     */
    public function upload()
    {
        if ($this->validate()) {
            $filePath = 'uploads/' . $this->imageFile->baseName . '.' . $this->imageFile->extension;
            if ($this->imageFile->saveAs($filePath)) {
                $this->image = $filePath;
                return true;
            } else {
                Yii::error('File not saved: ' . $filePath);
            }
        } else {
            Yii::error('Validation failed: ' . json_encode($this->errors));
        }
        return false;
    }

     /**
     * @inheritdoc
     */
    public function beforeDelete()
    {
        if (parent::beforeDelete()) {
            // Delete the image file from the uploads directory
            $imagePath = Yii::getAlias('@webroot/uploads/') . $this->image; // Adjust the path as per your setup
            if (is_file($imagePath) && $this->image !== 'default_image.jpg') {
                unlink($imagePath); // Delete the image file
            }

            return true;
        } else {
            return false;
        }
    }
}
