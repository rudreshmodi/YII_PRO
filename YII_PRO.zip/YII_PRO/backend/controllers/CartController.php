<?php

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use backend\models\Products; 

class CartController extends Controller
{
    public function actionIndex()
    {
        // Retrieve cart items from session or database
        $cartItems = Yii::$app->session->get('cart', []);

        return $this->render('index', [
            'cartItems' => $cartItems,
        ]);
    }

    public function actionAddToCart($id)
    {
        // Retrieve Products by ID
        $Products = Products::findOne($id);

        if (!$Products) {
            throw new \yii\web\NotFoundHttpException("Products not found");
        }

        // Retrieve cart items from session
        $cartItems = Yii::$app->session->get('cart', []);

        // Add Products to cart
        if (isset($cartItems[$id])) {
            $cartItems[$id]['quantity']++;
        } else {
            $cartItems[$id] = [
                'Products' => $Products,
                'quantity' => 1,
            ];
        }

        // Store updated cart items in session
        Yii::$app->session->set('cart', $cartItems);

        // Redirect to cart page
        return $this->redirect(['cart/index']);
    }

    public function actionClearCart()
    {
        // Clear cart items from session
        Yii::$app->session->remove('cart');

        // Redirect to cart page
        return $this->redirect(['cart/index']);
    }
}
