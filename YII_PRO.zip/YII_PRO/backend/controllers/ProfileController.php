<?php

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use backend\models\ProfileForm; // Import your ProfileForm model

class SiteController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['profile'],
                'rules' => [
                    [
                        'actions' => ['profile'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
        ];
    }

    public function actionProfile()
    {
        $user = Yii::$app->user->identity;
                $model = new ProfileForm();
        $model->loadFromUser($user);

        if ($model->load(Yii::$app->request->post()) && $model->saveToUser($user)) {
            Yii::$app->session->setFlash('success', 'Profile updated successfully.');
            return $this->refresh();
        }

        return $this->render('profile', [
            'model' => $model,
        ]);
    }
}
?>
