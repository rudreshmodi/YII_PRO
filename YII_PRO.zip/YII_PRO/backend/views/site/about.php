<?php

/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container-fluid col-lg-12">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Welcome to our About Us page. Here you can learn more about our company and what we stand for.</p>

    <div>
        <h2>Our Mission</h2>
        <p>At [Your Company Name], our mission is to [describe your mission statement or goal]. We strive to [explain your objectives and purpose].</p>

        <h2>Our History</h2>
        <p>Established in [year], [Your Company Name] has been [brief history of your company]. Over the years, we have [highlight key milestones or achievements].</p>

        <h2>Meet Our Team</h2>
        <p>Our team consists of dedicated professionals who bring diverse skills and expertise to [Your Company Name]. We are passionate about [describe team's passion or expertise].</p>

        <h2>Why Choose Us?</h2>
        <ul>
            <li>Quality products/services</li>
            <li>Exceptional customer service</li>
            <li>Innovative solutions</li>
            <li>Proven track record</li>
            <li>Community involvement</li>
        </ul>

        <h2>Customer Testimonials</h2>
        <div class="row">
            <div class="col-md-6">
                <blockquote>
                    <p>"[Customer testimonial]"</p>
                    <footer>[Customer Name], [Company/Organization]</footer>
                </blockquote>
            </div>
            <div class="col-md-6">
                <blockquote>
                    <p>"[Customer testimonial]"</p>
                    <footer>[Customer Name], [Company/Organization]</footer>
                </blockquote>
            </div>
        </div>

        <h2>Company Culture</h2>
        <p>At [Your Company Name], we foster a culture of [describe your company culture]. We value [mention core values or principles] and believe in [describe what your company believes in].</p>

        <h2>Contact Us</h2>
        <p>For more information about [Your Company Name] or to get in touch with us, please visit our <a href="<?= Yii::$app->urlManager->createUrl(['site/contact']) ?>">Contact Us</a> page.</p>
    </div>
</div>
