<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Profile';
$this->params['breadcrumbs'][] = $this->title;

$script = <<< JS
    $(document).ready(function() {
        // Disable new password and confirm password fields initially
        $('#model-newpassword, #model-confirmpassword, #model-submitbtn').prop('disabled', true);

        // Enable new password field only if current password is filled
        $('#model-oldpassword').on('input', function() {
            var currentPassword = $(this).val();
            if (currentPassword.trim() !== '') {
                $('#model-newpassword').prop('disabled', false);
            } else {
                $('#model-newpassword').prop('disabled', true);
                $('#model-confirmpassword').prop('disabled', true);
                $('#model-submitbtn').prop('disabled', true);

            }
        });

        // Enable confirm password field only if new password is filled
        $('#model-newpassword').on('input', function() {
            var newPassword = $(this).val();
            if (newPassword.trim() !== '') {
                $('#model-confirmpassword').prop('disabled', false);
            } else {
                $('#model-confirmpassword').prop('disabled', true);
                $('#model-submitbtn').prop('disabled', true);

            }
        });

        function checkSubmitButton() {
        var currentPassword = $('#model-oldpassword').val().trim();
        var newPassword = $('#model-newpassword').val().trim();
        var confirmPassword = $('#model-confirmpassword').val().trim();
        
        if (currentPassword !== '' && newPassword !== '' && confirmPassword !== '') {
            $('#model-submitbtn').prop('disabled', true);
        } else {
            $('#model-submitbtn').prop('disabled', false);
        }
    }
});
JS;

$this->registerJs($script);

?>

<div class="site-profile">
    <?php $form = ActiveForm::begin(['options' => ['class' => 'mt-4']]); ?>

    <div class="col-lg-12">
        <div class="row">
            <div class="col-lg-6">
                <!-- User Details -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h4 class="py-2">User Details</h4>
                    </div>
                    <div class="card-body">
                        <?= $form->field($model, 'username')->textInput(['maxlength' => true, 'class' => 'form-control', 'readonly' => true]) ?>
                        <?= $form->field($model, 'email')->textInput(['maxlength' => true, 'class' => 'form-control', 'readonly' => true]) ?>
                        <div class="form-group text-center">
                            <?= Html::button('Update', ['class' => 'btn btn-success mt-4', 'id' => 'update-button']) ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <!-- Password Update Section -->
                <div class="card mb-4" id="password-section" style="display: none;">
                    <div class="card-header bg-warning text-white">
                        <h4 class="mb-0">Change Password</h4>
                    </div>
                    <div class="card-body">
                        <?= $form->field($model, 'oldPassword')->passwordInput(['id' => 'model-oldpassword', 'maxlength' => true, 'class' => 'form-control'])->label('Current Password') ?>
                        <?= $form->field($model, 'newPassword')->passwordInput(['id' => 'model-newpassword', 'maxlength' => true, 'class' => 'form-control'])->label('New Password') ?>
                        <?= $form->field($model, 'confirmPassword')->passwordInput(['id' => 'model-confirmpassword', 'maxlength' => true, 'class' => 'form-control'])->label('Confirm New Password') ?>
                        <div class="form-group text-center">
                            <?= Html::submitButton('Change Password', ['id' => 'model-submitbtn', 'class' => 'btn btn-danger mt-4', 'name' => 'change-password-button']) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php ActiveForm::end(); ?>
</div>

<style>
    .site-profile .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .site-profile .card-header {
        text-align: center;
    }

    .site-profile .btn {
        width: 100%;
    }

    /* Adjust the width of the password section to expand next to user details card */
    #password-section {
        width: calc(100% - 20px); /* Adjust as per your layout */
        margin-left: 10px; /* Adjust margin for spacing */
        margin-right: 10px; /* Adjust margin for spacing */
    }

    /* Ensure the password fields take full width */
    #password-section .form-control {
        width: 100%;
    }
</style>

<script>
    document.getElementById('update-button').addEventListener('click', function() {
        document.getElementById('password-section').style.display = 'block';
    });
</script>
