<?php

use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Login';
$this->params['breadcrumbs'][] = $this->title;

// Check if user is not logged in
if (Yii::$app->user->isGuest) {
    // Display login form
?>
    <div class="container mx-auto mt-2">
        <div class="max-w-md mx-auto bg-white shadow-lg rounded px-4 pt-2 pb-4 mb-2">
            <h1 class="text-center text-2xl font-bold"><?= Html::encode($this->title) ?></h1>
            <p class="text-center mt-1">Please fill out the following fields to login:</p>

            <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>

            <?= $form->field($model, 'username')->textInput(['autofocus' => true, 'class' => 'shadow-sm form-input mt-2 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent']) ?>

            <?= $form->field($model, 'password')->passwordInput(['class' => 'shadow-sm form-input mt-2 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent']) ?>

            <?= $form->field($model, 'rememberMe')->checkbox(['class' => 'shadow-sm mt-2']) ?>

            <div class="text-xs mt-4" style="color:#999;">
                If you forgot your password you can <?= Html::a('reset it', ['site/request-password-reset'], ['class' => 'text-blue-500']) ?>.
                <br>
                Need a new verification email? <?= Html::a('Resend', ['site/resend-verification-email'], ['class' => 'text-blue-500']) ?>
            </div>

            <div class="flex items-center justify-center mt-4">
                <?= Html::submitButton('Login', ['class' => 'bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
<?php
} else {
    // If user is logged in, redirect or display appropriate message
    Yii::$app->getResponse()->redirect(Yii::$app->getHomeUrl());
}
?>
