<!-- all-products.php -->

<?php

use yii\helpers\Html;
use yii\helpers\Url;
use backend\models\Products;

/** @var backend\models\Products[] $products */

$this->title = 'All Products';
$this->params['breadcrumbs'][] = $this->title;
?>

<style>
    .product-card {
        position: relative;
        overflow: hidden;
        border-radius: 8px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        height: 100%;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .product-card img {
        width: 100%;
        height: 200px; /* Adjust height as needed */
        object-fit: cover;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .product-banner {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: rgba(0, 0, 0, 0.7);
        color: white;
        padding: 8px;
        border-radius: 4px;
        text-align: center;
        width: 80%;
    }

    .product-card .card-body {
        padding: 1rem;
    }

    .product-card .card-body h4 {
        margin-bottom: 0.5rem;
        font-size: 1.25rem;
        font-weight: bold;
    }

    .product-card .card-body p {
        margin-bottom: 1rem;
        font-size: 1rem;
    }

    .product-card .card-footer {
        background-color: #f8f9fa; /* Adjust background color as needed */
        padding: 1rem;
        text-align: center;
    }

    .btn-primary {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 4px;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>
<div class="site-all-products">
    <h1><?= Html::encode($this->title) ?></h1>

    <div class="row">
        <?php foreach ($products as $product): ?>
            <?php if ($product->status == 'Active'): ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <div class="product-card shadow">
                        <?= Html::img(Yii::$app->request->baseUrl . '/' . $product->image, ['class' => 'card-img-top', 'alt' => Html::encode($product->name)]) ?>
                        
                        <div class="product-banner" style="background-color: red; position:relative; top :40px; padding:0; left:220px;">
                            <p class="text-center mt-2">Price: Rs. <?= Html::encode($product->price) ?></p>
                        </div>

                        <div class="card-body">
                            <h5><?= Html::encode($product->price) ?></h5>
                            <h3 class="mt-2">Description:</h3>
                            <p><?= Html::encode($product->description) ?></p>
                        </div>

                        <div class="card-footer">
                            <?= Html::a('View Details', ['view', 'id' => $product->id], ['class' => 'btn btn-primary']) ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>

