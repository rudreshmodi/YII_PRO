<?php

use backend\models\Student;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;

/** @var yii\web\View $this */
/** @var backend\models\StudentSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Students';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="student-index">

    <h4><?= Html::encode($this->title) ?></h4>

    <p>
        <?= Html::a('Create Student', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php Pjax::begin(); ?>

    <div class="grid-view-container">
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            // 'filterModel' => $searchModel,
            'columns' => [
                
                // ID column
                [
                    'attribute' => 'id',
                    'headerOptions' => ['style' => 'width: 50px;'], // Example: Set header width
                    'contentOptions' => ['style' => 'text-align: center;'], // Example: Center align content
                ],

                // Enroll Number column
                [
                    'attribute' => 'enroll_number',
                    'headerOptions' => ['style' => 'width: 80px;'], // Example: Set header width
                    'contentOptions' => ['style' => 'text-align: center; width:80px;'], // Example: Center align content
                ],

                // First Name column
                [
                    'attribute' => 'first_name',
                    'contentOptions' => ['style' => 'font-weight: bold; width:200px;'], // Example: Make text bold
                ],

                // Last Name column
                [
                    'attribute' => 'last_name',
                    'contentOptions' => ['style' => 'width: 200px;'], // Example: Set width
                ],

                // Gender column
                [
                    'attribute' => 'gender',
                    'contentOptions' => ['style' => 'text-align: left; width:100px;'], // Example: Center align content
                ],

                // Created At column
                [
                    'attribute' => 'created_at',
                    'format' => ['date', 'php:Y-m-d H:i:s'],
                    'headerOptions' => ['style' => 'width: 150px;'], // Example: Set header width
                    'contentOptions' => ['style' => 'text-align: center;'], // Example: Center align content
                ],

                // Updated At column
                [
                    'attribute' => 'updated_at',
                    'format' => ['date', 'php:Y-m-d H:i:s'],
                    'headerOptions' => ['style' => 'width: 150px;'], // Example: Set header width
                    'contentOptions' => ['style' => 'text-align: center;'], // Example: Center align content
                ],

                // Action column
                [
                    'class' => 'yii\grid\ActionColumn',
                    'header' => 'Actions',
                    'headerOptions' => ['style' => 'text-align: center;'], // Example: Set header width
                    'template' => '{view} {update} {delete}',
                    'buttons' => [
                        'view' => function ($url, $model) {
                            return Html::a('<i class="fas fa-eye"></i>', $url, ['class' => 'btn btn-primary']);
                        },
                        'update' => function ($url, $model) {
                            return Html::a('<i class="fa-solid fa-pencil"></i>', $url, ['class' => 'btn btn-info']);
                        },
                        'delete' => function ($url, $model) {
                            return Html::a('<i class="fas fa-trash-alt"></i>', $url, [
                                'class' => 'btn btn-danger delete-button',
                                'data' => [
                                    'confirm' => 'Are you sure you want to delete this item?',
                                    'method' => 'post',
                                ],
                            ]);
                        },
                    ],
                    'contentOptions' => ['style' => 'white-space: nowrap; text-align: center;'],
                ],
            ],
            'tableOptions' => ['class' => 'table table-striped table-bordered'],
            'pager' => [
                'class' => \yii\widgets\LinkPager::class,
                'maxButtonCount' => 5,
                'options' => ['class' => 'pagination btn justify-content-end mt-3 mb-3'],
                'linkOptions' => [
                    'class' => 'page-link',
                    'style' => 'color: ; border: 1px solid darkgrey; border-radius: 4px; margin-left: 10px;',
                ],
            ],
        ]); ?>
    </div>
    <?php Pjax::end(); ?>

</div>

<style>
    .grid-view-container {
        width: 100%;
    }
</style>
