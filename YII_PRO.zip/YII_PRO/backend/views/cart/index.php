<!-- views/cart/index.php -->

<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Shopping Cart';
$this->params['breadcrumbs'][] = $this->title;
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php if (empty($cartItems)): ?>
    <p>Your shopping cart is empty.</p>
<?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>Products Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cartItems as $id => $item): ?>
                <tr>
                    <td><?= Html::encode($item['Products']->name) ?></td>
                    <td><?= Yii::$app->formatter->asCurrency($item['Products']->price) ?></td>
                    <td><?= Html::encode($item['quantity']) ?></td>
                    <td><?= Yii::$app->formatter->asCurrency($item['Products']->price * $item['quantity']) ?></td>
                    <td>
                        <?= Html::a('Remove', ['remove-from-cart', 'id' => $id], ['class' => 'btn btn-danger btn-sm']) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="text-right">
        <?= Html::a('Clear Cart', ['clear-cart'], ['class' => 'btn btn-danger']) ?>
        <?= Html::a('Continue Shopping', ['site/index'], ['class' => 'btn btn-primary']) ?>
    </div>
<?php endif; ?>
