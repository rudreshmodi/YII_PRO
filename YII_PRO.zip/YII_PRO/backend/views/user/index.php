<?php

use backend\models\User;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/** @var yii\web\View $this */
/** @var backend\models\UserSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Users';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="user-index">

    <h4><?= Html::encode($this->title) ?></h4>

    <p>
        <?= Html::a('Create User', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <div class="grid-view-container">
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            // 'filterModel' => $searchModel,
            'columns' => [
                // ID column
                [
                    'attribute' => 'id',
                    'headerOptions' => ['style' => 'text-align: center;'], // Example: Set header width
                    'contentOptions' => ['style' => 'text-align: left; width:50px;'], // Example: Center align content
                ],
                
                // Username column
                [
                    'attribute' => 'username',
                    'contentOptions' => ['style' => 'font-weight: bold; width:250px;'], // Example: Make text bold
                    'headerOptions' => ['style' => 'text-align: center;'], // Example: Set header width

                ],
                
                // Password column (masked)
                [
                    'attribute' => 'password',
                    'headerOptions' => ['style' => 'text-align: center;'], // Example: Set header width
                    'format' => 'raw',
                    'value' => function ($model) {
                        $stars = str_repeat('*', strlen($model->password));
                        return $stars;
                    },
                    'contentOptions' => ['style' => 'white-space: nowrap; text-align:center;width:350px;'], 
                ],
                
                // Email column
                [
                    'attribute' => 'email',
                    'format' => 'email',
                    'headerOptions' => ['style' => 'text-align: center;'], // Example: Set header width
                    'contentOptions' => ['style' => 'color: blue; width:300px;'], // Example: Set text color
                ],
                
                // Action column
                [
                    'class' => 'yii\grid\ActionColumn',
                    'header' => 'Actions',
                    'headerOptions' => ['style' => 'text-align: center;'], // Example: Set header width
                    'template' => '{view} {update} {delete}',
                    'buttons' => [
                        'view' => function ($url, $model) {
                            return Html::a('<i class="fas fa-eye"></i>', $url, ['class' => 'btn btn-primary']);
                        },
                        'update' => function ($url, $model) {
                            return Html::a('<i class="fa-solid fa-pencil"></i>', $url, ['class' => 'btn btn-info']);
                        },
                        'delete' => function ($url, $model) {
                            return Html::a('<i class="fas fa-trash-alt"></i>', $url, [
                                'class' => 'btn btn-danger delete-button',
                                'data' => [
                                    'confirm' => 'Are you sure you want to delete this item?',
                                    'method' => 'post',
                                ],
                            ]);
                        },
                    ],
                    'contentOptions' => ['style' => 'white-space: nowrap; text-align: center;'],
                ],
            ],
            'tableOptions' => ['class' => 'table table-striped table-bordered'],
            'pager' => [
                'class' => \yii\widgets\LinkPager::class,
                'maxButtonCount' => 3,
                'options' => ['class' => 'pagination btn justify-content-end mt-3 mb-3'],
                'linkOptions' => [
                    'class' => 'page-link',
                    'style' => 'color: ; border: 1px solid darkgrey; border-radius: 4px; margin-left: 10px;',
                ],
            ],
        ]); ?>
    </div>

</div>

<style>
    .grid-view-container {
        width: 100%;
        overflow-x: auto;
    }
</style>
