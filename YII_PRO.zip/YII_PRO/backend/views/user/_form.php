<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var backend\models\User $model */
/** @var yii\widgets\ActiveForm $form */
?>

<?php $form = ActiveForm::begin([
    'options' => ['class' => 'grid grid-cols-2 gap-4'],
    'fieldConfig' => [
        'options' => ['class' => 'mb-2'], // Adding margin bottom to each field
        'template' => "{label}\n{input}\n{error}", // Adjusting the field template
    ],
]); ?>

<?= $form->field($model, 'username')->textInput([
    'maxlength' => true,
    'class' => 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
])->label('Username') ?>

<?= $form->field($model, 'password')->passwordInput([
    'maxlength' => true,
    'class' => 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
])->label('Password') ?>

<?= $form->field($model, 'email')->textInput([
    'maxlength' => true,
    'class' => 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
])->label('Email') ?>

<div class="col-span-2 flex justify-end">
    <?= Html::a('Cancel', ['index'], [
        'class' => 'bg-gray-300 hover:bg-gray-800 text-gray-800 font-bold py-2 px-4 mr-4 rounded focus:outline-none focus:shadow-outline',
        'style' => 'text-decoration: none;', // Inline style to remove underline
    ]) ?>

    <?= Html::submitButton('Save', ['class' => 'bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline']) ?>
</div>

<?php ActiveForm::end(); ?>