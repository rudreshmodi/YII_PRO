<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var backend\models\User $model */

$this->title = 'Update User: ' . $model->username;
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id, 'username' => $model->username]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="user-create">
    <div class="flex ml-20 w-full bg-gray-300 rounded">
        <div class="max-w-screen w-full px-4 py-4">
            <div class="mx-auto bg-gray-100 shadow-md rounded px-8 pt-4 pb-4">
                <h4><?= Html::encode($this->title) ?></h4>
                <hr class='h-1 bg-dark'>
                <?= $this->render('_form', [
                    'model' => $model,
                ]) ?>
            </div>
        </div>
    </div>
</div>