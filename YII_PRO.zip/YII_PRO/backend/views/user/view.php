<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var backend\models\User $model */

$this->title = $model->username;
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="user-view cols-lg-12 mt-4">
    
    <div class="bg-white ml-64 shadow-md rounded px-8 pt-6 pb-8 mb-2">
    <h6 class="text-xl mb-4"><?= Html::a('<i class="fa-solid fa-arrow-left-long"></i>', ['index'],['class' => 'mr-1 p-1 text-gray-800 font-bold rounded','style' => 'text-decoration: none;',  ]) ?> <?= Html::encode($this->title) ?></h6>
 



        <?= DetailView::widget([
            'model' => $model,
            'options' => ['class' => 'table table-striped table-bordered detail-view rounded'],
            'attributes' => [
                'id',
                'username',
                [
                    'attribute' => 'password',
                    'value' => function ($model) {
                        // You can customize this to show stars or any other formatting for password
                        return '********'; // Example: showing stars instead of actual password
                    },
                ],
                'email:email',
            ],
        ]) ?>

        <div class="flex mb-4 w-full">
            <?= Html::a('<i class="fa-solid fa-pencil"> Update</i>', ['update', 'id' => $model->id, 'username' => $model->username], ['class' => 'btn btn-primary px-4 m-4']) ?>
            <?= Html::a('<i class="fas fa-trash-alt"> Delete</i>', ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger px-4 m-4',
                'data' => [
                    'confirm' => 'Are you sure you want to delete this item?',
                    'method' => 'post',
                ],
            ]) ?>
        </div>
    </div>
</div>