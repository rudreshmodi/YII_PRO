<?php

namespace console\controllers;

use yii\console\Controller;
use Yii;

class ExampleCommand extends Controller
{
    public function actionSendEmail($email)
    {
        $result = Yii::$app->mailer->compose()
            ->setTo($email)
            ->setSubject('Test Email')
            ->setTextBody('This is a test email.')
            ->send();

        if ($result) {
            echo "Email sent successfully to {$email}.\n";
        } else {
            echo "Failed to send email to {$email}.\n";
        }
    }
}
?>