<?php
return [
    'adminEmail' => 'modirudresh10@gmail.com',
    'supportEmail' => 'support@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'gmail.com mailer',
    'user.passwordResetTokenExpire' => 3600,
    'user.passwordMinLength' => 8,
    

'twilio' => [
    'Sid' => 'AC1c0e87b3b56557aabea6f2fa666187d8', //replace with your sid
    'token' => '0c9cbda7e207bd9ea7dcd06d9c452f5c', //replace with your token
    'sender' => '+15677773712',
]
];
