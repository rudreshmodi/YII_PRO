<?php

return [
    'components' => [
        'db' => [
            'class' => \yii\db\Connection::class,
            'dsn' => 'mysql:host=127.0.0.1;dbname=rudresh',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.gmail.com',
                'username' => 'modirudresh10@gmail.com',
                'password' => 'okpdyfkdhlaiqtbg',
                'port' => '587',
                'encryption' => 'tls',
            ],
        ],
        'twilio' => [
            'class' => 'common\components\TwilioComponent',
            'Sid' => 'AC1c0e87b3b56557aabea6f2fa666187d8', //  Twilio Account SID
            'token' => '0c9cbda7e207bd9ea7dcd06d9c452f5c', //  Twilio Auth Token
            'sender' => '+15677773712', // Twilio phone number
        ],
    ],
    'params' => array_merge(
        require __DIR__ . '/params.php',
        
    ),
];
