<?php

namespace common\components;

use Twilio\Rest\Client;
use Yii;
use yii\base\Component;

class TwilioComponent extends Component
{
    public $Sid;
    public $Token;
    public $from;

    public function init()
    {
        parent::init();
        
        // Fetch Twilio configuration from Yii params
        $twilioConfig = Yii::$app->params['twilio'];
        
        // Assign configuration values to class properties
        $this->Sid = $twilioConfig['Sid'];
        $this->Token = $twilioConfig['token'];
        $this->from = $twilioConfig['sender'];
    }

    /**
     * Sends OTP code via SMS using Twilio.
     *
     * @param string $to The recipient's phone number
     * @param int $otp The OTP code to send
     * @return string|null The message SID if successfully sent, null otherwise
     */
    public function sendOtp($to, $otp)
    {
        try {
            // Initialize Twilio client with account SID and auth token
            $client = new Client($this->Sid, $this->Token);

            // Send SMS message
            $message = $client->messages->create(
                $to,
                [
                    'from' => $this->from,
                    'body' => "Your OTP code is: $otp"
                ]
            );

            return $message->sid; // Return the SID of the sent message
        } catch (\Exception $e) {
            Yii::error("Twilio error: " . $e->getMessage());
            return null; 
        }
    }
}
