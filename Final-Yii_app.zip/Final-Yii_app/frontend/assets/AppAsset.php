<?php

namespace frontend\assets;

use yii\web\AssetBundle;

/**
 * Main frontend application asset bundle.
 */
class AppAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        // 'vendor/fontawesome-free/css/all.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css',
        'https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css',
        'https://cdn.jsdelivr.net/npm/tailwindcss@2.0.4/dist/tailwind.min.css',
        // 'https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i',
        'https://stackpath.bootstrapcdn.com/bootstrap/5.1.0/css/bootstrap.min.css',
        'css/sb-admin-2.min.css',
        'css/site.css',
        
    ];

    public $js = [
        'vendor/jquery/jquery.min.js',
        'https://stackpath.bootstrapcdn.com/bootstrap/5.1.0/js/bootstrap.bundle.min.js',
        'vendor/bootstrap/js/bootstrap.bundle.min.js',
        'vendor/jquery-easing/jquery.easing.min.js',
        'js/sb-admin-2.min.js',
        'vendor/chart.js/Chart.min.js',
        'js/demo/chart-area-demo.js',
        'js/demo/chart-pie-demo.js',
        'js/demo/scripts.js',
        'https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.24.0/ckeditor.js', 
        // '//cdn.ckeditor.com/4.24.0-lts/standard/ckeditor.js'
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap5\BootstrapAsset',
    ];
}
