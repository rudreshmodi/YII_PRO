<?php

namespace frontend\models;

use common\models\User;
use yii\base\Model;
use yii\base\InvalidArgumentException;

class VerifyEmailForm extends Model
{
    /**
     * @var string
     */
    public $token;

    /**
     * @var User
     */
    private $_user;

    /**
     * VerifyEmailForm constructor.
     *
     * @param string $token
     * @param array $config
     * @throws InvalidArgumentException
     */
    public function __construct($token, $config = [])
    {
        if (empty($token) || !is_string($token)) {
            throw new InvalidArgumentException('Verify email token cannot be blank.');
        }
        $this->_user = User::findByVerificationToken($token);
        if (!$this->_user) {
            throw new InvalidArgumentException('Wrong verify email token.');
        }
        $this->token = $token;
        parent::__construct($config);
    }

    /**
     * Verify email and activate user account.
     *
     * @return User|null the user model if verification is successful
     */
    public function verifyEmail()
    {
        $user = $this->_user;
        $user->status = User::STATUS_ACTIVE; // Assuming you have a constant STATUS_ACTIVE in your User model
        return $user->save(false) ? $user : null; // Save without validation as we are manually updating the status
    }
}
