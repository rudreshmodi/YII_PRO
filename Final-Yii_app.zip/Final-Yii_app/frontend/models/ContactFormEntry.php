<?php

namespace frontend\models;

use Yii;
use yii\db\ActiveRecord;
use common\models\User; // Adjust as per your user model namespace

class ContactFormEntry extends ActiveRecord
{
    public static function tableName()
    {
        return 'contact_form_entries';
    }

    public function rules()
    {
        return [
            [['name', 'email', 'subject', 'body'], 'required'],
            ['email', 'email'],
            ['user_id', 'integer'],
        ];
    }

    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'user_id']);
    }
}
