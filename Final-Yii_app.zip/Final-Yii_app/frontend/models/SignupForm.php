<?php

namespace frontend\models;

use Yii;
use yii\base\Model;
use common\models\User;
use Twilio\Rest\Client;

/**
 * Signup form
 */
class SignupForm extends Model
{
    public $username;
    public $email;
    public $password;
    public $phone;
    public $country_code;
    public $otp; // Define OTP property

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            ['username', 'trim'],
            ['username', 'required'],
            ['username', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This username has already been taken.'],
            ['username', 'string', 'min' => 2, 'max' => 255],
            ['email', 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['email', 'string', 'max' => 255],
            ['email', 'unique', 'targetClass' => '\common\models\User', 'message' => 'This email address has already been taken.'],
            ['password', 'required'],
            ['password', 'string'],
            ['phone', 'required'],
            ['phone', 'string'],
            ['country_code', 'required'],
            ['country_code', 'string', 'max'=> 5],
        ];
    }

    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
    public function signup()
    {
        if (!$this->validate()) {
            return null;
        }

        $user = new User();
        $user->username = $this->username;
        $user->email = $this->email;
        $user->setPassword($this->password);
        $user->generateAuthKey();
        $user->phone = $this->country_code . $this->phone;

        // Generate OTP
        $otp = strval(mt_rand(100000, 999999));
        $user->otp = $otp; // Assign OTP to user model

        // Generate email verification token
        $user->generateEmailVerificationToken();

        // Save user record
        if ($user->save()) {
            Yii::$app->session->setFlash('success', 'Registration successful. Please check your email for verification instructions.');
            // Send OTP via Twilio
            $this->sendOtp($user->phone, $otp);

            // Send verification email
            $this->sendEmail($user);

            return $user;
        }

        return null;
    }

    /**
     * Sends OTP via Twilio or any other service.
     *
     * @param string $phone
     * @param string $otp
     * @return bool whether OTP was sent successfully
     */
    protected function sendOtp($phone, $otp)
    {
        // Replace this with your actual code to send OTP via Twilio or any other service
        try {
            $sid = Yii::$app->params['twilio']['Sid'];
            $token = Yii::$app->params['twilio']['token'];
            $twilioNumber = Yii::$app->params['twilio']['sender'];

            $twilio = new Client($sid, $token);
            $message = $twilio->messages
                ->create(
                    $phone, // to
                    [
                        "from" => $twilioNumber,
                        "body" => "Your OTP for registration is: " . $otp,
                    ]
                );

            return true;
        } catch (\Exception $e) {
            Yii::error('Failed to send OTP: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Sends confirmation email to user
     * @param User $user user model with email to which the email should be sent
     * @return bool whether the email was sent successfully
     */
    protected function sendEmail($user)
    {
        return Yii::$app
            ->mailer
            ->compose(
                ['html' => 'emailVerify-html', 'text' => 'emailVerify-text'],
                ['user' => $user]
            )
            ->setFrom([Yii::$app->params['supportEmail'] => Yii::$app->name . ' robot'])
            ->setTo($user->email)
            ->setSubject('Account registration at ' . Yii::$app->name)
            ->send();
    }
}
