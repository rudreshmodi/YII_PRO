<?php
use yii\helpers\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;
use yii\web\View;

/* @var $this View */

$this->title = 'About Us';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- Custom CSS -->
    <style>
         .top-txt {
        background-color: black;
    }

    .head {
        display: flex;
        justify-content: space-between;
        color: rgba(255, 255, 255, 0.945);
        padding: 10px 0;
        font-size: 14px;
    }

    .head a {
        text-decoration: none;
        color: rgba(255, 255, 255, 0.945);
        margin: 0 10px;
    }

        /* Custom CSS styles for sections */
        .section {
            padding: 4%;
            background: #7e8890;
            color: #e6e6e6;
        }

        .navbar {
        box-shadow: 0 5px 4px rgb(146 161 176 / 15%);
        position: sticky;
        top: 0;
        background: var(--white);
        color: var(--black);
        z-index: 100;
    }

    .dropdown {
        justify-items: center;
        margin: auto;
        text-align: center;
        right: -4 0px;
    }

    .dropdown-menu {
        background-color: var(--white);
        color: var(--black);
        width: fit-content;
        cursor: pointer;
    }

    .dropdown-item {
        padding: 1px;
        padding-bottom: 3px;
        text-align: center;
        font-size: 16px;
        justify-items: center;
    }

    .navbar-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 64px;

    }

    .navbar img {
        width: 150px;
        height: 20px;
        margin-left: 3rem;
    }

    .menu-items {
        order: 2;
        display: flex;
        justify-content: baseline;
        align-items: center;
        margin-right: 3rem;

    }

    .menu-items li {
        list-style: none;
        margin-left: 1.5rem;
        font-size: 1.2rem;
    }

    .navbar-container ul a {
        text-decoration: none;
        color: var(--black);
        font-size: 18px;
        position: relative;
        left: 0px;
    }

    .navbar-container ul a:after {
        content: "";
        position: absolute;
        background: var(--primary-color);
        height: 3px;
        width: 0;
        left: 0;
        bottom: -10px;
        transition: 0.3s;
    }

    .navbar-container ul a:hover:after {
        width: 100%;
    }

        .newsletter-section {
            background-color: #007f;
            color: #fff;
            padding: 80px 0;
        }

        .newsletter-section h2,
        .newsletter-section p {
            margin-bottom: 20px;
        }

        .subscribe-form {
            max-width: 400px;
            margin: auto;
            padding: 0 15px;
        }

        .subscribe-form .input-group {
            position: relative;
            width: 100%;
        }

        .subscribe-form input[type="email"] {
            height: 50px;
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }

        .subscribe-form button {
            height: 50px;
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
        }

        .text-white {
            color: #fff !important;
        }

        .text-white:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<section class="top-txt">
        <div class="head container">
            <div class="head-txt">
                <p class="text-center m-2 mt-1">Free shipping, 30-day return or refund guarantee.</p>
            </div>
            <!-- <div class="sing_in_up ">
                <a href="# ">login</a>
                <a href="# ">SIGN UP</a>

            </div> -->
        </div>
    </section>
    <?php
    NavBar::begin([
        'brandLabel' => Html::img('https://i.postimg.cc/TP6JjSTt/logo.webp', ['alt' => 'Logo']),
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar navbar-expand-lg navbar-light',
        ],
    ]);

    $menuItems = [
        ['label' => 'Home', 'url' => Yii::$app->homeUrl],
        ['label' => 'About Us', 'url' => ['/site/about']],
        ['label' => 'Blog', 'url' => ['#news']],
        ['label' => 'Contact', 'url' => ['/site/contact']],
    ];

   

    echo Nav::widget([
        'options' => ['class' => 'navbar-nav ms-auto'],
        'items' => $menuItems,
        'encodeLabels' => false,
    ]);

    NavBar::end();
    ?>

    

    <!-- About Us Section -->
    <section id="about-us" class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2>About Us</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut ultricies velit. Suspendisse potenti. Sed id mi blandit, dapibus ipsum ut, sollicitudin urna. Donec gravida elit a nibh ultrices, eget malesuada risus dapibus.</p>
                    <p>Nullam vitae varius metus. Vivamus fermentum, augue eget rutrum feugiat, neque erat venenatis velit, id commodo odio orci eu lorem. Proin vestibulum consequat nisi. Vestibulum fringilla velit nec neque faucibus, eget finibus ante sollicitudin. Fusce sit amet congue lectus.</p>
                </div>
                <div class="col-lg-6">
                    <?= Html::img('https://picsum.photos/id/1/600/300', ['class' => 'img-fluid rounded', 'alt' => 'About Us Image']) ?>
                </div>
            </div>
        </div>
    </section>
    <!-- End About Us Section -->

    <!-- Services Section -->
    <section id="services" class="section">
        <div class="container">
            <h2 class="text-center mb-4">Our Services</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?= Html::img('https://picsum.photos/id/2/400/300/', ['class' => 'card-img-top rounded', 'alt' => 'Service 1']) ?>
                        <div class="card-body">
                            <h5 class="card-title">Service 1</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?= Html::img('https://picsum.photos/id/2/400/300/', ['class' => 'card-img-top rounded', 'alt' => 'Service 2']) ?>
                        <div class="card-body">
                            <h5 class="card-title">Service 2</h5>
                            <p class="card-text">Nullam vitae varius metus. Vivamus fermentum.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?= Html::img('https://picsum.photos/id/2/400/300/', ['class' => 'card-img-top rounded', 'alt' => 'Service 3']) ?>
                        <div class="card-body">
                            <h5 class="card-title">Service 3</h5>
                            <p class="card-text">Proin vestibulum consequat nisi. Vestibulum fringilla.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Services Section -->

    <!-- Team Section -->
    <section id="team" class="section">
        <div class="container">
            <h2 class="text-center mb-4">Our Team</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?= Html::img('https://picsum.photos/id/3/400/300/', ['class' => 'card-img-top rounded', 'alt' => 'Team Member 1']) ?>
                        <div class="card-body">
                            <h5 class="card-title">John Doe</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?= Html::img('https://picsum.photos/id/4/400/300/', ['class' => 'card-img-top rounded', 'alt' => 'Team Member 2']) ?>
                        <div class="card-body">
                            <h5 class="card-title">Jane Doe</h5>
                            <p class="card-text">Nullam vitae varius metus. Vivamus fermentum.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <?= Html::img('https://picsum.photos/id/5/400/300/', ['class' => 'card-img-top rounded', 'alt' => 'Team Member 3']) ?>
                        <div class="card-body">
                            <h5 class="card-title">Alice Smith</h5>
                            <p class="card-text">Proin vestibulum consequat nisi. Vestibulum fringilla.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Team Section -->

    <!-- Newsletter Section -->
    <section id="newsletter" class="newsletter-section">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-6">
                    <div class="text-center mb-4">
                        <h2 class="text-white">Join 2,000+ subscribers</h2>
                        <p class="text-white">Stay in the loop with everything you need to know.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <form class="subscribe-form">
                        <div class="input-group mb-3">
                            <input type="email" class="form-control" placeholder="Enter your email">
                            <button type="submit" class="btn btn-primary">Subscribe</button>
                        </div>
                    </form>
                    <div class="mt-3 text-center text-white">We care about your data in our <u class="cursor-pointer text-decoration-none">privacy policy</u>.</div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Newsletter Section -->

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

</body>

</html>
