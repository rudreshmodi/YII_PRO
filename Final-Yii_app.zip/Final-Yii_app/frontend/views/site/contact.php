<?php

use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;
use yii\captcha\Captcha;

// Set the page title
$this->title = 'Contact Us';

$url = 'https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js';
echo '<script src="' . htmlspecialchars($url, ENT_QUOTES) . '"></script>';

$this->beginPage();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900&display=swap"
        rel="stylesheet">
    <?php $this->head() ?>
    <style>
    html,
    body {
        height: 100%;
        margin: 0;
        overflow-x: hidden;
    }

    body {
        background-color: #f8f9fc;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0;
    }

    .container {
        width: 100%;
        box-sizing: border-box;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        padding: 0 20px;
    }

    .card {
        border: none;
        border-radius: 0.5rem;
        overflow: hidden;
        box-shadow: 0 0 1rem rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: row;
        align-items: stretch;
        width: 100%;
        background: #fff;
        margin: 0 10px;
    }

    .map {
        width: 45%;
        padding-left: 15px;
        margin: auto;
        margin-top: 50px;
        height: 100%;
    }

    .form-container {
        width: 55%;
        padding: 20px;
    }

    .form-control-user {
        border-radius: 0.5rem;
        padding: 1rem;
        font-size: 1rem;
        background-color: #ffffff;
        border: 1px solid #d1d3e2;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        width: 100%;
        box-sizing: border-box;
    }

    .form-control-user:focus {
        border-color: #4e73df;
        outline: 0;
        box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
    }

    .btn-user,
    .btn-reset {
        border-radius: 1rem;
        padding: 0.75rem 1.5rem;
        font-size: 1rem;
        width: 100%;
        box-sizing: border-box;
        text-align: center;
        display: inline-block;
        font-weight: bold;
        cursor: pointer;
    }

    .btn-user {
        color: #111;
        transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
    }

    .btn-user:focus {
        box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.5);
    }

    .btn-reset {
        background-color: gray;
        border-color: gray;
        /* color: #ffffff; */
        transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
    }

    .btn-reset:hover {
        background-color: slategrey;
        border-color: slategray;
    }

    .btn-reset:focus {
        box-shadow: 0 0 0 0.2rem rgba(0, 0, 0, 0.5);
    }

    .row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -10px;
        margin-left: -10px;
    }

    .col-lg-6 {
        flex: 0 0 50%;
        max-width: 50%;
        padding-right: 10px;
        padding-left: 10px;
    }

    .card__header {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 1.5rem;
    }

    .card__header span,
    .card__header a {
        font-weight: bold;
        text-align: center;
        padding: 0.5rem 1rem;
        cursor: pointer;
        text-decoration: none;
        color: #4e73df;
        border-bottom: 3px solid transparent;
        transition: color 0.15s ease-in-out, border-color 0.15s ease-in-out;
    }

    .card__header .card__signup {
        border-bottom-color: #4e73df;
    }

    .card__header .card__signin {
        color: #858796;
    }

    .card__header .card__signin:hover {
        color: #5a5c69;
    }

    /* Modal Styles */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow-y: scroll;
        background-color: rgba(0, 0, 0, 0.6);
    }

    .modal-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #999;
        width: 80%;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        animation-name: animatetop;
        animation-duration: 0.4s;
        /* Increased animation duration for smoother effect */
        animation-timing-function: ease-out;
        /* Easing function for smoother animation */
    }

    @keyframes animatetop {
        0% {
            transform: translateY(50px);
            /* Initial position off-screen */
            opacity: 0;
        }

        50% {
            transform: translateZ(-100px);
            /* Move down slightly */
            opacity: 1;
        }

        100% {
            transform: translateY(0);
            /* Final position on-screen */
            opacity: 1;
        }
    }

    .preview-header .close {
        color: #4e73df;
        font-size: 35px;
        top: 0;
        /* padding: 5px; */
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
    }

    /* Preview Modal Styles */
    .preview-header {
        background-color: #fefefe;
        color: #4e73df;
        padding: 5px;
        /* margin-bottom: 5px; */
        border-top-left-radius: 5px;
        border-top-right-radius: 5px;
    }

    .preview-body {
        padding: 20px;
        /* border: 1px solid #ddd;
        border-radius: 5px; */
        background-color: #ffffff;
    }

    .preview-body p {
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 5px;
        background-color: #f9f9f9;
        white-space: pre-wrap;
        margin-bottom: 10px;
    }

    .message-preview {
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 5px;
        background-color: #f9f9f9;
        white-space: pre-wrap;
    }

    .back-symbol {
        position: absolute;
        left: 20px;
        /* Adjusted right position */
        top: 10px;
        /* Added top position */
        text-decoration: none;
        color: #2d2747;
        font-weight: bolder;
        font-size: 26px;
        cursor: pointer;
    }
    </style>
</head>

<body>
    <?php $this->beginBody() ?>
    <div class="container">
        <div class="card o-hidden border-0 shadow-lg">
            <a href="<?= Yii::$app->request->referrer ?>" class="back-symbol"><i class="fa-solid fa-xmark"></i></a>
            <div class="map">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.977620366287!2d72.56427437407478!3d23.024593916255157!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e84d59d09890d%3A0xfdceac8c4ce642b8!2sXcelTec%20Interactive%20Private%20Limited%20-%20A%20CMMI%20Level%205%20Company!5e0!3m2!1sen!2sin!4v1721641520962!5m2!1sen!2sin"
                    width="450" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <div class="form-container">
                <div class="col-lg-12 p-4">
                    <div class="text-center">
                        <h1 class="h2 bolder text-gray-900"><?= Html::encode($this->title) ?></h1>
                        <p>If you have business inquiries or other questions, please fill out the following form to
                            contact us. Thank you.</p>
                    </div>
                    <?php $form = ActiveForm::begin(['id' => 'contact-form']); ?>
                    <div class="row">
                        <div class="col-lg-6">
                            <?= $form->field($model, 'name')->textInput(['autofocus' => true, 'placeholder' => $model->getAttributeLabel('name'), 'class' => 'form-control form-control-user'])->label(false) ?>
                        </div>
                        <div class="col-lg-6">
                            <?= $form->field($model, 'email')->textInput(['placeholder' => $model->getAttributeLabel('email'), 'class' => 'form-control form-control-user'])->label(false) ?>
                        </div>
                    </div>
                    <?= $form->field($model, 'subject')->textInput(['placeholder' => $model->getAttributeLabel('subject'), 'class' => 'form-control form-control-user'])->label(false) ?>
                    <?= $form->field($model, 'body')->textarea(['id' => 'editor', 'placeholder' => $model->getAttributeLabel('body'), 'class' => 'form-control form-control-user'])->label(false) ?>
                    <?= $form->field($model, 'verifyCode')->widget(Captcha::class, [
                        'template' => '<div class="row"><div class="col-lg-3">{image}</div><div class="col-lg-9">{input}</div></div>',
                        'options' => ['class' => 'form-control form-control-user', 'placeholder' => $model->getAttributeLabel('verifyCode')],
                    ])->label(false) ?>
                    <div class="row">
                        <div class="col-lg-4">
                            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary btn-user btn-block', 'name' => 'contact-button']) ?>
                        </div>
                        <div class="col-lg-4">
                            <?= Html::resetButton('Reset', ['class' => 'btn btn-secondary btn-reset btn-block', 'name' => 'reset-button']) ?>
                        </div>
                        <div class="col-lg-4">
                            <?= Html::button('Preview', ['class' => 'btn btn-warning btn-user btn-block', 'name' => 'preview-button', 'id' => 'previewButton']) ?>
                        </div>

                    </div>
                    <?php ActiveForm::end(); ?>
                    <!-- Modal -->
                    <div id="previewModal" class="modal">
                        <div class="modal-content">
                            <div class="preview-header">
                                <h3 class="close">&times;</h3>
                                <h3>Preview Email Content</h3>
                            </div>
                            <div id="previewContent" class="preview-body">
                                <!-- Preview content will be inserted here -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $this->endBody() ?>
    <script>
    ClassicEditor.create(document.querySelector('#editor'))
        .then(editor => {
            var modal = document.getElementById("previewModal");
            var previewContent = document.getElementById("previewContent");

            function openModal() {
                modal.style.display = "block";

                var name = document.querySelector('#<?= Html::getInputId($model, 'name') ?>').value;
                var email = document.querySelector('#<?= Html::getInputId($model, 'email') ?>').value;
                var subject = document.querySelector('#<?= Html::getInputId($model, 'subject') ?>').value;
                var message = editor.getData();

                var previewHTML = `
                    <span><strong>Name:</strong> <p>${name}</p></span>
                    <span><strong>Email:</strong> <p>${email}</p></span>
                    <span><strong>Subject:</strong> <p>${subject}</p></span>
                    <span><strong>Message:</strong></span>
                    <div class="message-preview">${message}</div>
                `;

                previewContent.innerHTML = previewHTML;
            }

            var span = document.getElementsByClassName("close")[0];
            span.onclick = function() {
                modal.style.display = "none";
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }

            document.getElementById('previewButton').addEventListener('click', function(event) {
                event.preventDefault();
                openModal();
            });

            document.getElementById('contact-form').addEventListener('submit', function(event) {
                // Additional handling or validation can be added here
            });
        })
        .catch(error => {
            console.error('Error initializing CKEditor:', error);
        });
    </script>
</body>

</html>
<?php $this->endPage() ?>