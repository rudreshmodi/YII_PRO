<?php

/* @var $this yii\web\View */
/* @var $model frontend\models\OtpForm */

use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Resend OTP';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="site-resend-otp">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>Please enter your username or email to resend OTP:</p>

    <?php $form = ActiveForm::begin(['id' => 'resend-otp-form']); ?>

    <?= $form->field($model, 'username')->textInput(['autofocus' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Resend OTP', ['class' => 'btn btn-primary', 'name' => 'resend-otp-button']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
