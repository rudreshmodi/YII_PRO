<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'OTP Verification';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <style>
        

        /* Container for limiting width */
        .container {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            width: 100%;
            max-width: 600px; /* Adjust max-width as needed */
            padding: 0 0px;
            box-sizing: border-box;
        }

        /* Card styles */
        .card {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease-in-out;
            box-sizing: border-box;
        }

       

        .card h1 {
            font-size: 28px;
            font-weight: bold;
            color: #1a8cff;
            margin-bottom: 20px;
        }

        .card p {
            font-size: 16px;
            color: #666666;
            margin-bottom: 30px;
        }

        /* Form styles */
        .form-control {
            width: 100%;
            padding: 15px;
            border: 1px solid #1a8cff;
            border-radius: 5px;
            font-size: 18px;
            margin-bottom: 20px;
            transition: border-color 0.3s;
            box-sizing: border-box;
        }

        .form-control:focus {
            outline: none;
            border-color: #0b5ed7;
            box-shadow: 0 0 10px rgba(26, 140, 255, 0.5);
        }

        .btn {
            width: 60%;
            padding: 15px;
            border: none;
            background-color: #1a8cff;
            color: #ffffff;
            font-size: 18px;
            font-weight: bold;
            border-radius: 12px;
            cursor: pointer;
            margin-bottom: 10px;
            transition: background-color 0.3s;
            box-sizing: border-box;
        }

        .btn:hover {
            background-color: #0b5ed7;
            color: white;
        }

        .resend-link {
            font-size: 14px;
            color: #1a8cff;
            text-decoration: none;
            transition: color 0.3s;
            display: block;
            margin-top: 20px;
        }

        .resend-link:hover {
            color: #0b5ed7;
        }

        /* Note styles */
        .note {
            font-size: 12px;
            color: #ff0000;
            margin-top: 10px;
            text-align: left;
        }

        /* Error message styles */
        .help-block {
            color: #ff0000;
            font-size: 12px;
            margin-top: 5px;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1><?= Html::encode($this->title) ?></h1>
            <p>Enter the 6-digit verification code that was sent to your phone number.</p>

            <?php $form = ActiveForm::begin(['id' => 'form-otp']); ?>
            <?= $form->field($model, 'otp', [
                'inputOptions' => [
                    'autofocus' => true,
                    'placeholder' => 'Enter OTP...',
                    'class' => 'form-control',
                    'maxlength' => 6,
                    'autocomplete' => 'off',
                    'onpaste' => 'return false;',
                    'oncopy' => 'return false;',
                    'oninput' => 'this.value = this.value.replace(/[^0-9]/g, "").slice(0, 6)',
                ],
                'template' => "{input}\n{error}",
            ])->textInput(['autofocus' => true])->label(false) ?>

            <?= Html::submitButton('Verify OTP', ['class' => 'btn', 'name' => 'verify-button']) ?>

            <?php ActiveForm::end(); ?>

            <p id="resend-section">Didn't receive the code? <?= Html::a('Resend OTP', ['site/resend-otp'], ['id' => 'resend-link', 'class' => 'resend-link']) ?></p>

            <div class="note">Note: Pasting is not allowed and only numeric characters are allowed.</div>
        </div>
    </div>

    <script>
        // Prevent pasting into the OTP input field
        document.addEventListener('DOMContentLoaded', function() {
            var otpInput = document.querySelector('#<?= Html::getInputId($model, 'otp') ?>');
            otpInput.addEventListener('paste', function(e) {
                e.preventDefault();
                showPasteNotAllowedMessage();
            });
            

            // Validate input to allow only numeric characters
            otpInput.addEventListener('input', function(e) {
                var inputValue = e.target.value;
                var numericRegex = /^[0-9]+$/;
                if (!numericRegex.test(inputValue)) {
                    e.target.setCustomValidity('Only numbers are allowed.');
                } else {
                    e.target.setCustomValidity('');
                }
            });
        });

        // Resend link timer
        var resendLink = document.getElementById('resend-link');
        var resendSection = document.getElementById('resend-section');
        var resendTimer;

        function startResendTimer() {
            var seconds = 30;
            resendLink.style.pointerEvents = 'none'; // Disable link
            resendTimer = setInterval(function() {
                seconds--;
                if (seconds > 0) {
                    resendSection.innerHTML = `Didn't receive the code? Resend OTP (${seconds}s)`;
                } else {
                    clearInterval(resendTimer);
                    resendLink.style.pointerEvents = 'auto'; // Enable link
                    resendSection.innerHTML = `Didn't receive the code? <?= Html::a('Resend OTP', ['site/resend-otp'], ['id' => 'resend-link', 'class' => 'resend-link']) ?>`;
                }
            }, 1000);
        }

        startResendTimer(); // Start the timer when the page loads
    </script>
</body>
</html>
