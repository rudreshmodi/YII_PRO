<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap5\ActiveForm $form */
/** @var \common\models\LoginForm $model */

use frontend\assets\AppAsset;
use yii\bootstrap5\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Male Fashion | Sign In';
AppAsset::register($this);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <style>
            body {
            background-color: #f8f9fc;
            font-family: Arial, sans-serif;
        }

        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            border: none;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 1rem rgba(0, 0, 0, 0.1);
        }

        .form-control-user {
            border-radius: 0.5rem;
            padding: 1em;
            margin-left: 15px;
            font-size: 1rem;
            background-color: #ffffff;
            border: 1px solid #d1d3e2;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control-user:focus {
            border-color: #4e73df;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }

        .btn-user {
            border-radius: 0.5rem;
            width: 200px;
            margin: auto;
            padding: 0.5rem 1rem;
            font-size: 1rem;
            background-color: #4e73df;
            border-color: #4e73df;
            transition: background-color 0.3s ease;
        }

        .btn-user:hover {
            background-color: #375ab5;
            border-color: #375ab5;
        }

        .btn-user:focus {
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.5);
        }

        .card__header {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 1.5rem;
        }

        .card__header span,
        .card__header a {
            font-weight: bold;
            text-align: center;
            padding: 0.5rem 1rem;
            cursor: pointer;
            text-decoration: none;
            color: #4e73df;
            border-bottom: 3px solid transparent;
            transition: color 0.15s ease-in-out, border-color 0.15s ease-in-out;
        }


        .card__header .card__signin {
            border-bottom-color: #4e73df;
        }

        .card__header .card__signup {
            color: #858796;
        }

        .card__header .card__signup:hover {
            color: #5a5c69;
        }

        .card-img {
            max-width: 100%;
            height: auto;
        }

        .has-error .form-control-user {
            position: sticky;
            top: 0;
            z-index: 1;
        }

        .forgot-password {
            text-align: center;
            margin:auto;
            margin-top: 5px;
            text-decoration: none;
            color: #4e73df;
        }
        .forgot-password:hover {
            text-decoration: none;
            color: #375ab5;
        }
    </style>
</head>

<body>
<div class="container">
        <div class="col-xl-10 col-lg-12 col-md-9">
            <div class="card o-hidden border-0 shadow-lg">
                <div class="card-body p-0">
                    <div class="card__header">
                        <a class="card__signup" href="<?= Yii::$app->urlManager->createUrl(['site/signup']) ?>">Sign up</a>
                        <span class="card__signin">Sign in</span>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 d-none d-lg-block">
                            <img src="https://img.freepik.com/free-vector/computer-login-concept-illustration_114360-7962.jpg?t=st=1720680286~exp=1720680886~hmac=c64b33c453ba88eab34bf46eb058cb545ff0e74fbce28edb8fe01716f57f7d6a" class="card-img" alt="login_hero">
                        </div>
                        <div class="col-lg-6 mt-10">
                            <div class="m-5">
                                <div class="text-center mb-6">
                                    <h1 class="h4 text-gray-900 mb-8">Welcome Back!</h1>
                                </div>
                                <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>
                                <div class="form-group mb-4">
                                    <div class="input-group">
                                        <span class="card__icon">
                                            <svg width="26" height="40" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                                <circle cx="12" cy="7" r="4"></circle>
                                            </svg>
                                        </span>
                                        <?= $form->field($model, 'email')->textInput([
                                            'placeholder' => 'Email',
                                            'class' => 'form-control form-control-user'
                                        ])->label(false) ?>
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <div class="input-group">
                                        <span class="card__icon">
                                            <svg width="26" height="40" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                            </svg>
                                        </span>
                                        <?= $form->field($model, 'password')->passwordInput([
                                            'placeholder' => 'Password',
                                            'class' => 'form-control form-control-user'
                                        ])->label(false) ?>
                                    </div>
                                </div>
                                <div class="form-group mb-4">
                                    <?= $form->field($model, 'rememberMe')->checkbox([
                                        'class' => 'form-check-input'
                                    ])->label('Remember Me', ['class' => 'form-check-label']) ?>
                                </div>
                                <div class="form-group mb-4">
                                    <?= Html::submitButton('Login', [
                                        'class' => 'btn btn-primary btn-user btn-block',
                                        'name' => 'login-button'
                                    ]) ?>
                                </div>
                                <?php ActiveForm::end(); ?>
                                <div>
                                    <a href="<?= Yii::$app->urlManager->createUrl(['site/request-password-reset']) ?>" class="forgot-password">Forgot password?</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>