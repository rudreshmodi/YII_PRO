<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap5\ActiveForm $form */
/** @var \frontend\models\ResetPasswordForm $model */

use yii\bootstrap5\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Reset password';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        integrity="sha384-PoO/Xa3Gh2lf6pV2MnA7vG2AWm8F8+CGlvT+L66n7uUpr2MlHMq7vea6DrxMsNWI" crossorigin="anonymous">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fc;
        }

        .bg-image {
            background-image: url('https://img.freepik.com/free-vector/forgot-password-concept-illustration_114360-1123.jpg?size=626&ext=jpg&ga=GA1.1.88164514.1720853745&semt=ais_user');
            background-size: cover;
            background-position: center;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card mt-5">
                    <div class="card-body p-4">
                        <h2 class="text-center mb-4"><?= Html::encode($this->title) ?></h2>
                        <?php $form = ActiveForm::begin(['id' => 'reset-password-form']); ?>
                            <?= $form->field($model, 'password', [
                                'template' => "{label}\n{input}\n{error}",
                                'inputOptions' => ['class' => 'form-control mb-3']
                            ])->passwordInput(['placeholder' => 'New Password'])->label(false) ?>

                            <div class="form-group text-center">
                                <?= Html::submitButton('Save', ['class' => 'btn btn-primary btn-block']) ?>
                            </div>
                        <?php ActiveForm::end(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ZMkqc5JZo0mNlStJupH9aZEl6PRYwG3MTuX+Z1EIGDFA+H2Zp5z7/Xr/HiXc+pHH" crossorigin="anonymous">
    </script>
</body>

</html>
