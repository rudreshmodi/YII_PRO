<?php

use frontend\assets\AppAsset;
use yii\bootstrap5\Html;
use yii\bootstrap5\ActiveForm;

use function PHPSTORM_META\type;

// Register assets and set title
$this->title = 'Signup';
AppAsset::register($this);

$js = <<< JS
    $(document).ready(function() {
        $('#signupform-password, #signupform-password_repeat').on('keyup', function() {
            var password = $('#signupform-password').val().trim(); // Trim whitespace
            var confirmPassword = $('#signupform-password_repeat').val().trim(); // Trim whitespace
            
            if (password === confirmPassword && password !== '') { // Check if passwords match and are not empty
                $('#password-message').html('<span class="text-success">Passwords match</span>');
                $('#signup-button').prop('disabled', false);
            } else {
                $('#password-message').html('<span class="text-danger">Passwords do not match</span>');
                $('#signup-button').prop('disabled', true);
            }
        });
        
        $(document).on('click', '.toggle-password', function() {
            togglePasswordVisibility();
        });

        // Function to adjust eye icon position
        function adjustEyeIconPosition() {
            var passwordField = $('#signupform-password');
            var icon = $('.toggle-password');

            // Check if password field is in sticky state
            if (passwordField.hasClass('is-sticky')) {
                var inputHeight = passwordField.outerHeight();
                var iconTop = (inputHeight - icon.outerHeight()) / 2;
                icon.css('top', iconTop + 'px');
            } else {
                icon.css('top', ''); // Reset to default if not sticky
            }
        }

        // Call adjustEyeIconPosition initially and on window resize
        adjustEyeIconPosition();
        $(window).on('resize', adjustEyeIconPosition);
    });
    
    // Toggle password visibility function
    function togglePasswordVisibility() {
        var passwordField = $('#signupform-password');
        var icon = $('.toggle-password');
        
        if (passwordField.attr('type') === 'password') {
            passwordField.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            passwordField.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }

        // Call adjustEyeIconPosition to reposition icon
        adjustEyeIconPosition();
    }

    $(document).ready(function() {
        var input = document.querySelector("#phone");
        var iti = window.intlTelInput(input, {
            initialCountry: "auto",
            preferredCountries: ["in", "us", "gb"],
            separateDialCode: true,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
        });

        // Listen to the 'countrychange' event to update the hidden field
        input.addEventListener('countrychange', function(e) {
            var countryData = iti.getSelectedCountryData();
            $('#country_code').val('+' + countryData.dialCode);
        });
    });
JS;
$this->registerJs($js);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Global Styles */
        body {
            background-color: #f8f9fc;
            font-family: Arial, sans-serif;
        }

        .container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            border: none;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 1rem rgba(0, 0, 0, 0.1);
        }

        .form-control-user {
            border-radius: 0.5rem;
            padding: 1rem;
            font-size: 1rem;
            background-color: #ffffff;
            border: 1px solid #d1d3e2;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .form-control-user:focus {
            border-color: #4e73df;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }

        .btn-user {
            border-radius: 0.5rem;
            width: 200px;
            margin: auto;
            padding: 0.5rem 1rem;
            font-size: 1rem;
            background-color: #4e73df;
            border-color: #4e73df;
            transition: background-color 0.3s ease;
        }

        .btn-user:hover {
            background-color: #375ab5;
            border-color: #375ab5;
        }

        .btn-user:focus {
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.5);
        }

        .card__header {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 1.5rem;
        }

        .card__header span,
        .card__header a {
            font-weight: bold;
            text-align: center;
            padding: 0.5rem 1rem;
            cursor: pointer;
            text-decoration: none;
            color: #4e73df;
            border-bottom: 3px solid transparent;
            transition: color 0.15s ease-in-out, border-color 0.15s ease-in-out;
        }

        .card__header .card__signup {
            border-bottom-color: #4e73df;
        }

        .card__header .card__signin {
            color: #858796;
        }

        .card__header .card__signin:hover {
            color: #5a5c69;
        }

        .position-relative {
            position: relative;
        }

        .field-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #ccc;
            background-color: #ffffff;
            padding: 10px;
            border-radius: 0 5px 5px 0;
            z-index: 1;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .field-icon:hover {
            color: #666;
        }

        .card-img {
            max-width: 100%;
            height: auto;
        }

        .has-error .form-control-user {
            position: sticky;
            top: 0;
            z-index: 1;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="col-xl-10 col-lg-12 col-md-9">
            <div class="card o-hidden border-0 shadow-lg">
                <div class="card-body p-0">
                    <div class="card__header">
                        <span class="card__signup">Sign up</span>
                        <a class="card__signin" href="<?= Yii::$app->urlManager->createUrl(['site/login']) ?>">Sign in</a>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mt-5 m-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-6">Signup</h1>
                                </div>
                                <?php $form = ActiveForm::begin(['id' => 'form-signup']); ?>

                                <div class="form-group">
                                    <?= $form->field($model, 'username')->textInput([
                                        'autofocus' => true,
                                        'autocomplete' => 'off',
                                        'onpaste' => 'return false;',
                                        'placeholder' => 'Enter Username...',
                                        'class' => 'form-control form-control-user'
                                    ])->label(false) ?>
                                </div>

                                <div class="form-group">
                                    <?= $form->field($model, 'email')->textInput([
                                        'placeholder' => 'Enter Email Address...',
                                        'autocomplete' => 'off',
                                        'class' => 'form-control form-control-user'
                                    ])->label(false) ?>
                                </div>

                                <div class="form-group">
                                    <?= $form->field($model, 'phone')->textInput([
                                        'id' => 'phone',
                                        'style' => 'width:335px;',
                                        'class' => 'form-control form-control-user',
                                        'placeholder' => 'Phone Number',
                                        'oninput' => 'formatPhoneNumber(this);',
                                        'onpaste' => 'return false;',
                                    ])->label(false) ?>
                                </div>

                                <?= $form->field($model, 'country_code')->hiddenInput(['id' => 'country_code'])->label(false) ?>

                                <div class="position-relative mb-4">
                                    <?= $form->field($model, 'password', [
                                        'template' => "{input}\n{error}",
                                        'options' => ['class' => 'position-relative'], // Add class for positioning
                                    ])->passwordInput([
                                        'id' => 'signupform-password',
                                        'placeholder' => 'Password',
                                        'onpaste' => 'return false;',
                                        'class' => 'form-control form-control-user',
                                        'autocomplete' => 'off', // Disable autocomplete for password fields
                                    ])->label(false) ?>
                                    <i class="fa-solid fa-eye toggle-password field-icon" onclick="togglePasswordVisibility()" toggle="#signupform-password"></i>
                                </div>

                                <div class="form-group">
                                    <?= $form->field($model, 'password')->textInput([
                                        'id' => 'signupform-password_repeat',
                                        'placeholder' => 'Confirm Password',
                                        'onpaste' => 'return false;',
                                        'class' => 'form-control form-control-user'
                                    ])->label(false) ?>
                                    <div id="password-message"></div>
                                </div>

                                <?= Html::submitButton('Sign up', [
                                    'id' => 'signup-button',
                                    'class' => 'btn btn-primary btn-user btn-block',
                                    'name' => 'signup-button',
                                    'disabled' => true, // Disable button by default
                                ]) ?>

                                <?php ActiveForm::end(); ?>
                                <hr>
                            </div>
                        </div>
                        <div class="col-lg-6 d-none d-lg-block">
                            <!-- <img src="https://img.freepik.com/free-vector/editing-body-text-concept-illustration_114360-5661.jpg?t=st=1720702543~exp=1720706143~hmac=dff6348c8f207e1940a966eda71dd695fd60c7a8297eef2e21e184961f0a9bb4&w=740" class="card-img" alt="signup_hero"> -->
                            <img src="https://img.freepik.com/free-vector/sign-up-concept-illustration_114360-7965.jpg?size=338&ext=jpg&ga=GA1.1.2008272138.1721174400&semt=ais_user" class="card-img" alt="signup_hero">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"></script>

    <script>
        function formatPhoneNumber(input) {
            // Remove all non-numeric characters and limit to 10 digits
            input.value = input.value.replace(/\D/g, '').slice(0, 10);

            // Format the number as (xxx) xxx-xxxx if it's 10 digits
            if (input.value.length === 10) {
                input.value = '(' + input.value.substring(0, 3) + ') ' + input.value.substring(3, 6) + '-' + input.value.substring(6, 10);
            }
        }
    </script>

</body>

</html>
