<?php
/** @var $this yii\web\View */
/** @var $user frontend\models\User */

use yii\helpers\Html;
use yii\web\YiiAsset;


$this->title = 'User Profile';
?>

<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">

<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>

   <style>
    body {
    font-family: 'Roboto', sans-serif;
    line-height: 1.6;
    background-color: #e0f2f1;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.card-container {
    background-color: white;
    border-radius: 15px;
    box-shadow: 0px 10px 20px -10px rgba(0, 0, 0, 0.75);
    padding-top: 30px;
    position: relative;
    width: 480px;
    max-width: 100%;
    text-align: center;
    margin-bottom: 30px;
}

.edit-symbol {
    position: absolute;
    right: 30px;
    text-decoration: none;
    color: #2d2747;
    font-size: 24px;
    cursor: pointer;
}

.back-symbol {
    position: absolute;
    right: 20px;
    top: 10px;
    text-decoration: none;
    color: #2d2747;
    font-weight: bolder;
    font-size: 26px;
    cursor: pointer;
}

.profile-image {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    margin: auto;
    background-size: contain;
    display: block;
    border: 1px solid #fff;
    box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.3);
}

.imp-data {
    background-color: #26a69a;
    text-align: left;
    padding: 30px;
    margin-top: 30px;
    border-radius: 5px;
    color: #111;
}

.imp-data p {
    border: 1px solid #2d2747;
    border-radius: 5px;
    display: block;
    color: #111;
    font-size: 20px;
    margin: 10px 0;
    padding: 10px 20px;
    /* Adjusted padding */
}

.password {
    overflow-wrap: break-word;
    text-align: justify;
    color: #111;
}

.imp-data i {
    height: 20px;
    color: #111;
    margin-right: 10px;
}

@media (max-width: 768px) {
    .card-container {
        width: 90%;
    }
}

   </style>
</head>

<body>
    <div class="card-container">
        <a href="<?= Yii::$app->urlManager->createUrl(['site/index']) ?>" class="back-symbol"><i class="fa-solid fa-xmark"></i></a>
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLTUvtDbR7S4SLURbtbBpX5jCx_SWfaDp5h2yh7YQnD1sKHIpCJOYIxhlo2yLE98AEAYw&usqp=CAU" alt="Profile Image" class="profile-image">
        <div class="imp-data">
            <p><i class="fa-solid fa-user"></i> <?= Html::encode($user->username) ?></p>
            <p><i class="fa-solid fa-envelope"></i> <?= Html::encode($user->email) ?></p>
            <p class="password"><i class="fa-solid fa-lock"></i><a href="<?= Yii::$app->urlManager->createUrl(['site/request-password-reset']) ?>" class="edit-symbol"><i class="fas fa-edit"></i></a>

                <?php
                $passwordStars = str_repeat('*', strlen($user->password_hash) - 20);
                echo Html::encode($passwordStars);
                ?>
            </p>
            <p><i class="fa-solid fa-phone"></i>
                <?php
                if ($user->phone) {
                    echo Html::encode($user->phone);
                } else {
                    echo "No phone number";
                }
                ?>
            </p>
        </div>
    </div>
</body>

</html>