<?php

/** @var yii\web\View $this */
/** @var string $name */
/** @var string $message */
/** @var Exception $exception */

use yii\helpers\Html;
use yii\web\NotFoundHttpException; // Ensure this import if Exception is a NotFoundHttpException

$this->title = '404 - ' . $message;
$this->params['body-class'] = 'bg-gradient-primary'; // Add a class for a gradient background (optional)
?>

<section class="page_404">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="col-sm-10 text-center">
                    <div class="four_zero_four_bg">
                        <h1 class="text-center ">404</h1>
                    </div>
                    <div class="contant_box_404">
                        <h2 class="h2">
                            Look like you're lost
                        </h2>
                        <p>the page you are looking for not avaible!</p>
                        <a href="<?= Yii::$app->urlManager->createUrl(['site/index']) ?>" class="link_404">Go to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<style>
    .page_404 {
        width: 100%;
        overflow-x: hidden;       
        justify-content: center;
        background: #fff;
        font-family: 'Arvo', serif;
    }

    .page_404 img {
        /* width: 100%; */
        margin-left: 50px;

    }

    .four_zero_four_bg {

        background-image: url(https://cdn.dribbble.com/users/285475/screenshots/2083086/dribbble_1.gif);
        min-height: 400px;
        background-position: center;
        margin: 40px 0 0 180px;
    }


    .four_zero_four_bg h1 {
        font-size: 80px;

    }

    .four_zero_four_bg h3 {
        font-size: 80px;

    }

    .link_404 {
        color: #fff !important;
        border-radius: 18px;
        padding: 10px 20px;
        background: #39ac31;
        margin: 20px 0;
        text-decoration: none; /* Remove underline by default */
        display: inline-block;
        text-underline-offset: 0;
    }

    .link_404:hover {
        text-decoration: none; /* Remove underline on hover */
    }

    .contant_box_404 {
        margin-top: -40px;
        margin-left: 180px;

    }
</style>