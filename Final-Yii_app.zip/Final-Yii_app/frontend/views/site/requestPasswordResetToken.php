    <?php

    /** @var yii\web\View $this */
    /** @var yii\bootstrap5\ActiveForm $form */
    /** @var \frontend\models\PasswordResetRequestForm $model */

    use yii\bootstrap5\Html;
    use yii\bootstrap5\ActiveForm;

    $this->title = 'Request password reset';
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= Html::encode($this->title) ?></title>
        <style>
        /* Add your custom styles here */
        body {
            font-family: 'Roboto', sans-serif;
        }

        .bg-image {
            background-image: url('https://img.freepik.com/free-vector/forgot-password-concept-illustration_114360-1123.jpg?size=626&ext=jpg&ga=GA1.1.88164514.1720853745&semt=ais_user');
            background-size: cover;
            background-position: center;
        }

        .back-to-dashboard {
            margin-top: 20px;
            /* Adjust margin-top as needed */
            text-align: center;
            /* Center the link */
        }

        .back-link {
            padding: 10px 20px;
            color: #111;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }

        .back-link i {
            margin-right: 8px;
            /* Adjust the space between icon and text */
        }

        .back-link:hover {
            color: #2980b9;
            text-decoration: none;
        }

        .back-link:hover i {
            color: #2980b9;
        }
        </style>
    </head>

    <body class="font-mono bg-gray-400">
        <!-- Container -->
        <div class="container mx-auto">
            <div class="flex justify-center items-center h-screen px-6">
                <!-- Row -->
                <div class="w-full xl:w-3/4 lg:w-11/12 flex">
                    <!-- Col - Image Background -->
                    <div class="w-full h-auto bg-gray-400 hidden lg:block lg:w-1/2 rounded-l-lg bg-image">
                    </div>
                    <!-- Col - Form Section -->
                    <div class="w-full lg:w-1/2 bg-white p-8 lg:p-12 rounded-lg lg:rounded-l-none">
                        <div class="text-center mb-8">
                            <h3 class="text-2xl font-bold text-gray-900">Forgot Your Password?</h3>
                            <p class="text-sm text-gray-700 mt-2">
                                Don't worry, it happens. Enter your email below and we'll send you a link to reset your
                                password.
                            </p>
                        </div>
                        <?php $form = ActiveForm::begin(['id' => 'request-password-reset-form', 'class' => 'space-y-4']); ?>
                        <?= $form->field($model, 'email')->textInput(['id' => 'email', 'class' => 'w-full px-4 py-2 border rounded-md focus:outline-none focus:ring focus:border-blue-300', 'placeholder' => 'Enter Email Address', 'autocomplete' => 'off']) ?>
                        <div class="text-center">
                            <?= Html::submitButton('Reset Password', ['class' => 'w-full py-2 px-4 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 focus:outline-none focus:bg-blue-600']) ?>
                        </div>
                        <?php ActiveForm::end(); ?>
                        <hr class="my-8 border-t" />
                        <div class="text-center">
                            <?php if (Yii::$app->user->isGuest) : ?>
                            <p class="text-sm text-gray-600">Don't have an account? <a
                                    href="<?= Yii::$app->urlManager->createUrl(['site/signup']) ?>"
                                    class="text-blue-500 hover:text-blue-800">Sign Up Here</a></p>
                            <p class="mt-2 text-sm text-gray-600">Remembered your password? <a
                                    href="<?= Yii::$app->urlManager->createUrl(['site/login']) ?>"
                                    class="text-blue-500 hover:text-blue-800">Login Here</a></p>
                            <?php else : ?>
                            <p class="mt-2 text-sm text-gray-600 back-to-dashboard">
                                <a href="<?= Yii::$app->request->referrer ?>" class="back-link">
                                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                                </a>
                            </p>
                            <?= Html::endForm() ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>