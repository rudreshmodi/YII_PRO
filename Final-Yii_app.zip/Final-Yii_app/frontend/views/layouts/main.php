<?php

/** @var \yii\web\View $this */
/** @var string $content */

use common\widgets\Alert;
use frontend\assets\AppAsset;
use yii\bootstrap5\Breadcrumbs;
use yii\bootstrap5\Html;
use yii\bootstrap5\Nav;
use yii\bootstrap5\NavBar;
use yii\helpers\Url;

AppAsset::register($this);

if (Yii::$app->user->isGuest && !in_array(Yii::$app->controller->action->id, ['login', 'signup', 'verify-otp', 'resend-otp', 'request-password-reset', 'reset-password', 'profile'])) {
    Yii::$app->getResponse()->redirect(Url::to(['site/login']))->send();
    Yii::$app->end();
}

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">

<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>

<body class="flex-column h-100">
    <?php $this->beginBody() ?>
    <?php if (!Yii::$app->user->isGuest) : ?>
        <!-- <header>
            <?php
            NavBar::begin([
                'brandLabel' => Yii::$app->name,
                'brandUrl' => Yii::$app->homeUrl,
                'options' => [
                    'class' => 'navbar navbar-expand-md navbar-light bg-light text-dark fixed-top',
                ],
            ]);
            $menuItems = [
                ['label' => 'Home', 'url' => ['/site/index']],
                ['label' => 'About', 'url' => ['/site/about']],
                ['label' => 'Contact', 'url' => ['/site/contact']],
            ];
            if (Yii::$app->user->isGuest) {
                $menuItems[] = ['label' => 'Signup', 'url' => ['/site/signup']];
            }

            echo Nav::widget([
                'options' => ['class' => 'navbar-nav me-auto mb-0 mb-md-0'],
                'items' => $menuItems,
            ]);
            if (Yii::$app->user->isGuest) {
                echo Html::tag('div', Html::a('Login', ['/site/login'], ['class' => ['btn btn-link login text-decoration-none']]), ['class' => ['d-flex']]);
            } else {
                echo Html::beginForm(['/site/logout'], 'post', ['class' => 'd-flex'])
                    . Html::submitButton(
                        'Logout (' . Yii::$app->user->identity->username . ')',
                        ['class' => 'btn btn-link logout text-decoration-none']
                    )
                    . Html::endForm();
            }
            NavBar::end();
            ?>
        </header> -->
    <?php endif; ?>

    <main role="main">
        <div>
            <?= Alert::widget() ?>

            <?= $content ?>
        </div>
    </main>

    <?php
    if (!Yii::$app->user->isGuest && !in_array(Yii::$app->controller->action->id, ['login', 'signup', 'profile', 'contact', 'error', 'verify-otp', 'resend-otp', 'request-password-reset', 'reset-password'])) : ?>
        <footer class="footer mt-auto py-3 text-muted">
            <div class="container">
                <p class="float-start">&copy; <?= Html::encode(Yii::$app->name) ?> <?= date('Y') ?></p>
                <p class="float-end"><?= Yii::powered() ?></p>
            </div>
        </footer>
    <?php endif; ?>

    <?php $this->endBody() ?>
</body>

</html>
<?php $this->endPage(); ?>

<script>
    // Script to remove flash message after 3 seconds
    setTimeout(function() {
        $('.alert').fadeOut('fast');
    }, 2000); // 3000 milliseconds = 3 seconds
</script>