<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var common\models\User $user */

$verifyLink = Yii::$app->urlManager->createAbsoluteUrl(['site/verify-email', 'token' => $user->verification_token]);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Template</title>
    <style>
        body {
            margin: 0;
            background: #FEFEFE;
            color: #585858;
            font-family: -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
        }

        .email-container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background: #FFFFFF;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .logo {
            margin: 30px auto;
            display: block;
        }

        h1 {
            font-size: 20px;
            font-weight: 500;
            margin-top: 40px;
            margin-bottom: 0;
        }

        p {
            margin-top: 10px;
            margin-bottom: 0;
            color: #585858;
        }

        a.button {
            display: inline-block;
            background-color: #20DA9C;
            color: #FFFFFF;
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 8px;
            margin-top: 20px;
            font-weight: bold;
        }

        small {
            display: block;
            margin-top: 14px;
            font-size: 14px;
            color: #585858;
        }

        .footer {
            background: #1FD99A;
            padding: 20px;
            text-align: center;
            margin-top: 20px;
            border-radius: 8px;
        }

        .footer p {
            margin-bottom: 10px;
        }

        .legal {
            font-size: 12px;
            color: #A5A5A5;
            line-height: 1.5;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="email-container">
        <img src="https://carpool-email-assets.s3.amazonaws.com/shared/carpool-logo@2x.png" width="232" class="logo" alt="Carpool Logo">
        <h1>Hi <?= Html::encode($user->username) ?>,</h1>
        <p>Please verify that your email address is <?= Html::encode($user->email) ?>, and that you entered it when signing up for Waze Carpool.</p>
        <?= Html::a('Verify email', $verifyLink, ['class' => 'button']) ?>
        <small>Wazers who carpool may see that you work at reallygoodemails.com, but your email address stays private.</small>

        <div class="footer">
            <img src="https://carpool-email-assets.s3.amazonaws.com/shared/footer@2x.png" width="500" alt="Footer Image">
            <p>More about <a href="http://waze.com/carpool/index.html" target="_blank">Waze Carpool</a></p>
            <p>Questions? <a href="https://support.google.com/waze/carpool" target="_blank">We're here</a></p>
            <p>Join the community <a href="https://www.facebook.com/groups/wazecarpoolers" target="_blank">on Facebook</a></p>
        </div>

        <p class="legal">If you did not enter this email address when signing up for Waze Carpool service, disregard this message.<br>
            © 2017 Google Inc. 1600 Amphitheatre Parkway, Mountain View, CA 94043<br><br>
            This is a mandatory service email from Waze Carpool.</p>
    </div>
</body>

</html>