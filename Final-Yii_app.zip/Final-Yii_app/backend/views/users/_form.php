<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var backend\models\Users $model */
/** @var yii\widgets\ActiveForm $form */
?>
<style>
/* Custom Input Styling */
.custom-input {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-bottom: 10px;
}

/* Custom Button Styling */
.custom-button {
    background-color: #28a745;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
}

.custom-button:hover {
    background-color: #218838;
}
</style>

<div class="user-form">
    <?php $form = ActiveForm::begin([
        'options' => ['class' => 'grid grid-cols-2 gap-4'],
        'fieldConfig' => [
            'options' => ['class' => 'mb-4'],
            'template' => "{label}\n{input}\n{error}",
            'labelOptions' => ['class' => 'text-sm font-bold text-gray-700'],
        ],
    ]); ?>

    <?= $form->field($model, 'username')->textInput(['class' => 'custom-input']) ?>



    <?= $form->field($model, 'email')->textInput(['class' => 'custom-input']) ?>


    <?= $form->field($model, 'password')->textInput(['class' => 'custom-input']) ?>

    <div class="mb-4 col-span-2 flex justify-end">
        <?= Html::submitButton('Save', ['class' => 'custom-button']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>