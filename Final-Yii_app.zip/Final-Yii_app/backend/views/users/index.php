<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;

/** @var yii\web\View $this */
/** @var backend\models\UsersSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Users';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="users-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php Pjax::begin(); ?>
    <div class="grid-view-container">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        // 'filterModel' => $searchModel,
        'tableOptions' => ['class' => 'table table-striped table-bordered'], // Bootstrap table styles
        'columns' => [

            'id',
            'username',
            'email:email',
            'password',
            [
                'class' => ActionColumn::className(),
                'template' => '{view} {update} {delete}',
                'buttons' => [
                    'view' => function ($url, $model) {
                        return Html::a('<i class="fas fa-eye"></i>', $url, ['class' => 'btn btn-primary']);
                    },
                    'update' => function ($url, $model) {
                        return Html::a('<i class="fa-solid fa-pencil"></i>', $url, ['class' => 'btn btn-info']);
                    },
                    'delete' => function ($url, $model) {
                        return Html::a('<i class="fas fa-trash-alt"></i>', $url, [
                            'class' => 'btn btn-danger delete-button',
                            'data' => [
                                'confirm' => 'Are you sure you want to delete this item?',
                                'method' => 'post',
                            ],
                        ]);
                    },
                ],
            ],
        ],
        'tableOptions' => ['class' => 'table table-striped table-bordered'],
        'pager' => [
            'class' => \yii\widgets\LinkPager::class,
            'maxButtonCount' => 5,
            'options' => ['class' => 'pagination btn justify-content-end mt-3 mb-3'],
            'linkOptions' => [
                'class' => 'page-link',
                'style' => 'color: ; border: 1px solid darkgrey; border-radius: 4px; margin-left: 10px;',
            ],
        ],
    ]); ?>
</div>
<?php Pjax::end(); ?>
</div>
