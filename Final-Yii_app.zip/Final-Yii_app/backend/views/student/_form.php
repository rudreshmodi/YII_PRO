<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Student Form';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>
    <!-- Include necessary CSS stylesheets -->
    <style>
    /* CSS styles here */
    .input-group {
        margin-bottom: 1rem;
    }

    .btn-user {
        padding: 0.5rem 1rem;
        cursor: pointer;

        border: none;
        border-radius: 0.25rem;
    }

    .btn:hover {
        background-color: #2d3748;
    }

    .btn-increment {
        margin-bottom: 0.5rem;
    }

    .btn-decrement {
        background-color: #ef4444;
    }

    .btn-decrement:hover {
        background-color: #dc2626;
    }

    .form-label {
        font-size: 0.875rem;
        font-weight: 600;
        color: #4a5568;
        margin-bottom: 0.25rem;
    }

    .form-input-wrapper {
        position: relative;
        display: inline-block;
        width: 100%;
    }

    .form-input {
        width: calc(100% - 2rem);
        /* Adjust based on button width */
        padding: 0.5rem;
        padding-right: 2rem;
        /* Space for button */
        border: 1px solid #d2d6dc;
        border-radius: 0.25rem;
        outline: none;
        transition: border-color 0.2s ease-in-out;
    }

    .form-input:focus {
        border-color: #6b46c1;
    }

    .form-error {
        color: #dc2626;
        /* Red color */
        font-size: 0.875rem;
        margin-top: 0.25rem;
        font-weight: 600;
        /* Optional: Increase font weight for emphasis */
    }


    .btn-inside {
        position: absolute;
        top: 5px;
        left: 445px;
        bottom: 1;
        padding: 0.2rem 0.5rem;
        background-color: white;
        color: black;
        border: none;
        border-radius: 0 0.25rem 0.25rem 0;
        cursor: pointer;
    }

    .btn-inside:hover {
        background-color: #4a5568;
        color: white;
        border-radius: 60%;
    }

    .help-block-error {
        color: #dc2626;
        /* Red color */
        font-size: 0.875rem;
        font-weight: 600;
        margin-top: 0.25rem;
    }
    </style>
</head>


<body>
    <div class="container">
        <h1><?= Html::encode($this->title) ?></h1>

        <?php $form = ActiveForm::begin([
            'id' => 'student-form',
            'options' => ['class' => 'grid grid-cols-2 gap-4'],
        ]); ?>

        <div class="mb-1">
            <?= $form->field($model, 'enroll_number')->textInput(['maxlength' => true, 'class' => 'form-input'])->label('Enroll Number', ['class' => 'form-label'])->error(['class' => 'help-block-error']) ?>
        </div>

        <div class="mb-1">
            <?= $form->field($model, 'first_name')->textInput(['maxlength' => true, 'class' => 'form-input'])->label('First Name', ['class' => 'form-label'])->error(['class' => 'help-block-error']) ?>
        </div>

        <div class="mb-1">
            <?= $form->field($model, 'last_name')->textInput(['maxlength' => true, 'class' => 'form-input'])->label('Last Name', ['class' => 'form-label'])->error(['class' => 'help-block-error']) ?>
        </div>

        <div class="mb-1">
            <?= $form->field($model, 'gender')->radioList(
                ['Male' => 'Male', 'Female' => 'Female', 'Other' => 'Other'],
                [
                    'itemOptions' => ['labelOptions' => ['class' => 'pr-4']],
                    'class' => 'flex items-center space-x-2'
                ]
            )->label('Gender', ['class' => 'form-label'])->error(['class' => 'help-block-error']) ?>
        </div>

        <div class="mb-1">
            <?= $form->field($model, 'attendance')->textInput(['maxlength' => true, 'class' => 'form-input'])->label('Attendance', ['class' => 'form-label'])->error(['class' => 'help-block-error']) ?>
        </div>

        <div class="mb-1">
            <?= $form->field($model, 'language')->checkboxList([
                'Urdu' => 'Urdu',
                'Telugu' => 'Telugu',
                'punjabi' => 'Punjabi',
                'gujarati' => 'Gujarati',
                'bengali' => 'Bengali',
                'Marathi' => 'Marathi',
            ])->label('Language', ['class' => 'form-label'])->hint('Select one or more')->error(['class' => 'help-block-error']) ?>
        </div>

        <div class="col-span-2 flex justify-end">
            <?= Html::a('Cancel', ['index'], ['class' => 'btn bg-gray-300 hover:bg-gray-800 text-gray-800 font-bold py-2 px-4 mr-4 rounded focus:outline-none focus:shadow-outline']) ?>
            <?= Html::submitButton('Save', ['class' => 'btn-user bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline']) ?>
        </div>

        <?php ActiveForm::end(); ?>
    </div>

    <!-- Include jQuery and your JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        var maxFields = 5; // Maximum number of language input fields

        // Function to handle increment button click
        $(document).on('click', '.btn-increment', function() {
            var languageFields = $('.language-field').length;
            if (languageFields < maxFields) {
                var lastLanguageField = $('.language-field').last();
                var newLanguageField = lastLanguageField.clone(true); // Include events and data
                newLanguageField.find('.btn-increment')
                    .remove(); // Remove increment button from cloned field
                newLanguageField.find('.form-error').empty(); // Clear any existing error messages
                newLanguageField.find('.form-input').val(''); // Clear input field value
                newLanguageField.appendTo(
                    '#language-fields'); // Append cloned input field to the container
                if (languageFields >= 1) {
                    addDecrementButton(newLanguageField); // Add decrement button if more than one field
                }
            }
            updateButtonVisibility();
        });

        // Function to handle decrement button click
        $(document).on('click', '.btn-decrement', function() {
            var inputGroup = $(this).closest('.language-field');
            inputGroup.remove(); // Remove the entire input group
            updateButtonVisibility();
        });

        // Function to add a decrement button to the input group
        function addDecrementButton(inputGroup) {
            var decrementButton = $('<button type="button" class="btn btn-inside btn-decrement">-</button>');
            inputGroup.find('.form-input-wrapper').append(decrementButton); // Append inside form input wrapper
        }

        // Function to update visibility of increment button
        function updateButtonVisibility() {
            var languageFields = $('.language-field').length;
            $('.btn-increment').show();
            if (languageFields >= maxFields) {
                $('.btn-increment').hide();
            }
        }

        // Form submission handling
        $('#student-form').submit(function() {
            // Convert all language inputs to a comma-separated string
            var languages = [];
            $('.form-input').each(function() {
                languages.push($(this).val());
            });
            // Join array into a single string separated by commas
            $('#studentform-language').val(languages.join(','));
            return true; // Allow form submission to proceed
        });
    });
    </script>
</body>

</html>