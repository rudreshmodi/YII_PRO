<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var backend\models\Student $model */

$this->title = $model->first_name;
$this->params['breadcrumbs'][] = ['label' => 'Students', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="flex items-center justify-center h-full">
    <div class="bg-white shadow-md rounded px-8 py-6" style="width: 600px;">
        <div class="flex items-center justify-between">
        <h6 class="text-xl mb-4"><?= Html::a('<i class="fa-solid fa-arrow-left-long"></i>', ['index'],['class' => 'mr-1 p-1 text-gray-800 font-bold rounded','style' => 'text-decoration: none;',  ]) ?> <?= Html::encode($this->title) ?></h6>

            <div>
            </div>
        </div>

        <?= DetailView::widget([
            'model' => $model,
            'options' => ['class' => 'table table-striped table-bordered detail-view rounded'],
            'attributes' => [
                'id',
                'enroll_number',
                'first_name',
                'last_name',
                'language',
                'gender',
                'attendance',
                'created_at',
                'updated_at',
            ],
        ]) ?>

        <div class="flex justify-center mt-4">
            <?= Html::a('<i class="fa-solid fa-pencil-alt"> Update</i> ', ['update', 'id' => $model->id], ['class' => 'btn btn-primary px-4 py-2 mr-2']) ?>
            <?= Html::a('<i class="fa-solid fa-trash-alt"> Delete</i> ', ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger px-4 py-2',
                'data' => [
                    'confirm' => 'Are you sure you want to delete this item?',
                    'method' => 'post',
                ],
            ]) ?>
        </div>
    </div>
</div>