<?php

/** @var yii\web\View $this */
/** @var string $name */
/** @var string $message */
/** @var Exception $exception */

use yii\helpers\Html;

$this->title = '404 - ' .$message;
$this->params['body-class'] = 'bg-gradient-primary'; // Add a class for a gradient background (optional)
?>

<div class="w-full mt-40 container-fluid justify-content-center">

    <!-- 404 Error Text -->
    <div class="text-center ml-36">
        <div class="error d-flex ml-64" data-text="404">404</div>
        <p class="lead text-gray-800 mb-5">Page Not Found</p>
        <p class="text-gray-500 mb-0">It looks like you found a glitch in the matrix...</p>
        <a href="<?= Yii::$app->urlManager->createUrl(['site/index']) ?>">&larr; Back to Dashboard</a>
    </div>

</div>