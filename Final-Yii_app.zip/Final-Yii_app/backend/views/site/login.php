<?php

use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;

$this->title = 'Admin-Panel | Login';
// $this->params['breadcrumbs'][] = $this->title;
AppAsset::register($this);
?>

<div class="container mx-auto">
    <div class="max-w-md mx-auto bg-white shadow-lg rounded px-8 py-8 mt-10">
        <h1 class="text-center text-3xl font-bold mb-6">Login</h1>
        <p class="text-center text-sm mb-6">Please fill out the following fields to login:</p>

        <?php $form = ActiveForm::begin([
            'id' => 'login-form',
            'options' => ['class' => 'space-y-4'],
            'fieldConfig' => [
                'options' => ['class' => 'relative'],
                'template' => "{input}\n{error}",
                'inputOptions' => ['class' => 'shadow-sm form-input block w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent'],
            ],
        ]); ?>

        <?= $form->field($model, 'email')->textInput(['autofocus' => true, 'placeholder' => 'Email Address']) ?>

        <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Password']) ?>

        <?= $form->field($model, 'rememberMe')->checkbox([
            'template' => "<div class=\"flex items-center\">{input} {label}</div>",
            'class' => 'shadow-sm',
        ]) ?>

        <div class="flex items-center justify-center">
            <?= Html::submitButton('Login', ['class' => 'bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline']) ?>
        </div>

        <?php ActiveForm::end(); ?>
    </div>
</div>