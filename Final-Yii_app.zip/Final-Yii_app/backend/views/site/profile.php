<?php

/** @var $this yii\web\View */
/** @var $model backend\models\User */

use yii\helpers\Html;

$this->title = 'User Profile';
?>

<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">

<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Html::encode($this->title) ?></title>

    <style>
    body {
        font-family: 'Roboto', sans-serif;
        line-height: 1.3;
        background-color: #e0f2f1;
        margin: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .card-container {
        background-color: white;
        border-radius: 15px;
        box-shadow: 0px 10px 10px -10px rgba(0, 0, 0, 0.75);
        padding-top: 15px;
        position: relative;
        width: 800px;
        /* width: 100%; */
        text-align: left;
        display: flex;
        /* Display children elements side by side */
        align-items: center;
        /* Align items vertically */
        margin-top: 70px;
    }

    .edit-symbol {
        position: absolute;
        right: 50px;
        text-decoration: none;
        color: #2d2747;
        font-size: 24px;
        cursor: pointer;
    }

    .back-symbol {
        position: absolute;
        right: 20px;
        top: 10px;
        text-decoration: none;
        color: #2d2747;
        font-weight: bolder;
        font-size: 26px;
        cursor: pointer;
    }

    .profile-image {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        margin: 20px;
        /* Adjust margin for spacing */
        background-size: contain;
        border: 1px solid #fff;
        box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.3);
    }

    .imp-data {
        background-color: #26a69a;
        padding: 30px;
        margin: 20px;
        /* Adjust margin for spacing */
        border-radius: 5px;
        color: #111;
        flex: 1;
        /* Take remaining space */
    }

    .imp-data p {
        border: 1px solid #2d2747;
        border-radius: 5px;
        display: block;
        color: #111;
        font-size: 20px;
        margin: 10px 0;
        padding: 10px 20px;
    }

    .password {
        overflow-wrap: break-word;
        text-align: justify;
        color: #111;
    }

    .imp-data i {
        height: 20px;
        color: #111;
        margin-right: 10px;
    }

    @media (max-width: 768px) {
        .card-container {
            flex-direction: column;
            /* Stack items vertically on smaller screens */
            align-items: center;
            /* Center items horizontally */
            padding: 20px;
        }

        .imp-data {
            margin-top: 30px;
            /* Increase margin for spacing */
        }
    }
    </style>
</head>

<body>
    <div class="card-container">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLTUvtDbR7S4SLURbtbBpX5jCx_SWfaDp5h2yh7YQnD1sKHIpCJOYIxhlo2yLE98AEAYw&usqp=CAU"
            alt="Profile Image" class="profile-image">
        <div class="imp-data">
            <a href="<?= Yii::$app->urlManager->createUrl(['site/index']) ?>" class="back-symbol"><i
                    class="fa-solid fa-xmark"></i></a>
            <h2>User Profile</h2>
            <p><i class="fa-solid fa-user"></i> <?= Html::encode($model->username) ?></p>
            <p><i class="fa-solid fa-envelope"></i> <?= Html::encode($model->email) ?></p>
            <p class="password"><i class="fa-solid fa-lock"></i>

                <?php
                $passwordStars = str_repeat('*', strlen($model->password_hash) - 20);
                echo Html::encode($passwordStars);
                ?>
                <a href="<?= Yii::$app->urlManager->createUrl(['site/request-password-reset']) ?>"
                    class="edit-symbol"><i class="fas fa-edit"></i></a>
            </p>
            <p><i class="fa-solid fa-phone"></i>
                <?php
                if ($model->phone) {
                    echo Html::encode($model->phone);
                } else {
                    echo "No phone number";
                }
                ?>
            </p>
        </div>
    </div>
</body>

</html>