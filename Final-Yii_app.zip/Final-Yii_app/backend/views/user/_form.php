<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var backend\models\User $model */
/** @var yii\widgets\ActiveForm $form */
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Form</title>

    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f7fafc;
            color: #2d3748;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 100%;
            margin: 0 auto;
            /* padding: 20px; */
        }

        /* Form Field Styling */
        .form-field {
            margin-bottom: 1.5rem;
        }

        .form-field label {
            font-size: 0.875rem;
            font-weight: bold;
            color: #4a5568;
            margin-bottom: 0.5rem;
            display: block;
        }

        .form-field input[type="text"],
        .form-field input[type="password"],
        .form-field select {
            width: 100%;
            padding: 0.75rem;
            font-size: 1rem;
            border-radius: 0.375rem;
            border: 1px solid #cbd5e0;
            transition: border-color 0.2s;
            outline: none;
            box-shadow: none;
        }

        .form-field input[type="text"]:focus,
        .form-field input[type="password"]:focus,
        .form-field select:focus {
            border-color: #4a90e2;
        }

        /* Error Message Styling */
        .error-message {
            font-size: 0.75rem;
            color: #e53e3e;
            margin-top: 0.25rem;
        }

        /* Dropdown List Styling */
        .form-field select {
            appearance: none;
            /* Remove default arrow in some browsers */
            background-color: white;
            background-image: url('data:image/svg+xml;utf8,<svg fill="#4a5568" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M7 7l3-3 3 3m-3 4l-3 3-3-3" /></svg>');
            background-repeat: no-repeat;
            background-position: right 0.75rem top 50%, 0 0;
            background-size: 1.5em auto, 100%;
            padding: 0.75rem 2rem 0.75rem 0.75rem;
            /* Adjust padding for better spacing */
            border-radius: 0.375rem;
            border: 1px solid #cbd5e0;
            transition: border-color 0.2s;
            outline: none;
            box-shadow: none;
            cursor: pointer;
            /* Show pointer cursor on hover */
        }

        .form-field select:focus {
            border-color: #4a90e2;
        }

        /* Dropdown Arrow Styling */
        .form-field select::-ms-expand {
            display: none;
            /* Remove default arrow in IE */
        }

        /* Submit Button Styling */
        .form-submit-button {
            margin-top: 1.5rem;
            text-align: right;
        }

        .form-submit-button button {
            padding: 10px 20px;
            font-size: 1rem;
            background-color: #48bb78;
            color: white;
            border: none;
            border-radius: 0.375rem;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-submit-button button:hover {
            background-color: #2f855a;
        }

        /* Grid Layout */
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            /* Adjust the gap between columns */
        }

        /* Responsive Grid Layout */
        @media (max-width: 600px) {
            .grid {
                grid-template-columns: 1fr;
                /* Display as single column on smaller screens */
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="user-form">
            <?php $form = ActiveForm::begin([
                'fieldConfig' => [
                    'options' => ['class' => 'form-field'],
                    'template' => "{label}\n{input}\n{error}",
                    'labelOptions' => ['class' => ''],
                    'inputOptions' => ['class' => ''],
                ],
            ]); ?>

            <div class="grid">
                <div>
                    <?= $form->field($model, 'username')->textInput(['class' => '']) ?>
                </div>
                <div>
                    <?php if (!$model->isNewRecord) : ?>
                        <?= $form->field($model, 'password_hash')->passwordInput(['maxlength' => true]) ?>
                    <?php else : ?>
                        <?= $form->field($model, 'password_hash')->textInput(['maxlength' => true])->label('New Password') ?>
                    <?php endif; ?>
                </div>
                <div>
                    <?= $form->field($model, 'email')->textInput(['class' => '']) ?>
                </div>
                <div>
                    <?= $form->field($model, 'role')->dropDownList(
                        [
                            'admin' => 'Admin',
                            'user' => 'User',
                        ],
                        [
                            'prompt' => 'Select Role',
                            'class' => '',
                        ]
                    ) ?>
                </div>
                <div>
                    <?= $form->field($model, 'phone')->textInput(['class' => '']) ?>
                </div>
            </div>

            <div class="col-span-2 flex justify-end">
                <?= Html::a('Cancel', ['index'], ['class' => 'bg-gray-300 hover:bg-gray-800 text-gray-800 font-bold py-2 px-4 mr-4 rounded focus:outline-none focus:shadow-outline', 'style' => 'text-decoration: none;']) ?>
                <?= Html::submitButton('Save', ['class' => 'bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
</body>

</html>