<?php

use yii\bootstrap5\Modal;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\GridView;
use yii\widgets\Pjax;

/** @var yii\web\View $this */
/** @var backend\models\ProductsSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Products';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="Products-index">
    <p>
        <?= Html::a('Create Products', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?php Pjax::begin(); ?>
    <div class="grid-view-container">
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            // 'filterModel' => $searchModel,
            'columns' => [
                // ['class' => 'yii\grid\SerialColumn'],
                [
                    'attribute' => 'id',
                    'headerOptions' => ['style' => 'width: 50px;'],
                    'contentOptions' => ['style' => 'text-align: center;'],
                ],

                // Product Name column
                [
                    'attribute' => 'name',
                    'headerOptions' => ['style' => 'width: 80px;'],
                    'contentOptions' => ['style' => 'font-weight: bold; text-align: center; width:80px;'],
                ],

                // Product Category column
                [
                    'attribute' => 'category',
                    'contentOptions' => ['style' => 'width:200px;'], // Example: Make text bold
                ],
                // Product Description column
                [
                    'attribute' => 'description',
                    'contentOptions' => ['style' => 'width:200px;'],
                ],
                // Product Price column
                [
                    'attribute' => 'price',
                    'headerOptions' => ['style' => 'width: 80px;'],
                    'contentOptions' => ['style' => 'text-align: center; width:80px;'],
                ],
                // Image column
                [
                    'headerOptions' => ['style' => 'text-align: center; width:300px;'],
                    'attribute' => 'image',
                    'format' => 'html',
                    'value' => function ($model) {
                        $imageUrl = Yii::$app->request->baseUrl . '/' . $model->image;
                        $defaultImageUrl = Yii::$app->request->baseUrl . '/img/default_image.jpg';

                        $fileExtension = pathinfo($model->image, PATHINFO_EXTENSION);

                        if (!empty($model->image) && file_exists(Yii::getAlias('@webroot') . '/' . $model->image)) {
                            if (in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif', 'bmp'])) {
                                return Html::img($imageUrl, [
                                    'class' => 'rounded-lg shadow-lg',
                                    'style' => 'width: auto; max-height: 250px; object-fit: contain;',
                                ]);
                            } elseif ($fileExtension === 'pdf') {
                                return Html::a('Download PDF', [$imageUrl], [
                                    'class' => 'btn btn-primary',
                                    'target' => '_blank',
                                    'data-pjax' => '0',
                                ]);
                            } else {
                                return Html::a('Download File', [$imageUrl], [
                                    'class' => 'btn btn-primary',
                                    'target' => '_blank',
                                    'data-pjax' => '0',
                                ]);
                            }
                        } else {
                            return Html::img($defaultImageUrl, [
                                'class' => 'rounded-lg shadow-lg',
                                'style' => 'width: auto; max-height: 250px; object-fit: contain;',
                            ]);
                        }
                    },
                ],
                // 'status'
                [
                    'class' => 'yii\grid\ActionColumn',
                    'header' => 'Status',
                    'template' => '{toggle-status}',
                    'buttons' => [
                        'toggle-status' => function ($url, $model, $key) {
                            return Html::tag(
                                'div',
                                Html::checkbox(
                                    'status',
                                    $model->status === 'Active',
                                    [
                                        'class' => 'switch-input',
                                        'id' => 'status-switch-' . $model->id,
                                        'data-id' => $model->id,
                                        'data-status' => $model->status,
                                        'data-url' => Url::to(['toggle-status', 'id' => $model->id]),
                                    ]
                                ) .
                                Html::tag('span', $model->status === 'Active' ? 'Active' : 'Inactive', [
                                    'id' => 'switch-status-text-' . $model->id,
                                    'class' => 'switch-status-text',
                                    'style' => $model->status === 'Active' ? 'color: green;' : 'color: red;'
                                ]),
                                
                                ['class' => 'form-group custom-switch mt-4']
                            );
                        },
                    ],
                ],


                [
                    'class' => 'yii\grid\ActionColumn',
                    'header' => 'Actions',
                    'headerOptions' => ['style' => 'text-align: center;'], // Example: Set header width
                    'template' => '{view} {update} {delete}',
                    'buttons' => [
                        'view' => function ($url, $model) {
                            return Html::a('<i class="fas fa-eye"></i>', $url, ['class' => 'btn btn-primary']);
                        },
                        'update' => function ($url, $model) {
                            return Html::a('<i class="fa-solid fa-pencil"></i>', $url, ['class' => 'btn btn-info']);
                        },
                        'delete' => function ($url, $model) {
                            return Html::a('<i class="fas fa-trash-alt"></i>', $url, [
                                'class' => 'btn btn-danger delete-button',
                                'data' => [
                                    'confirm' => 'Are you sure you want to delete this item?',
                                    'method' => 'post',
                                ],
                            ]);
                        },
                    ],
                    'contentOptions' => ['style' => 'white-space: nowrap; text-align: center;'],
                ],
            ],
            'tableOptions' => ['class' => 'table table-striped table-bordered'],
            'pager' => [
                'class' => \yii\widgets\LinkPager::class,
                'maxButtonCount' => 5,
                'options' => ['class' => 'pagination btn justify-content-end mt-3 mb-3'],
                'linkOptions' => [
                    'class' => 'page-link',
                    'style' => 'color: ; border: 1px solid darkgrey; border-radius: 4px; margin-left: 10px;',
                ],
            ],
        ]); ?>
    </div>
    <?php Pjax::end(); ?>

    <?php
    Modal::begin([
        'id' => 'confirm-modal',
        'title' => '<h4 class="modal-title">Confirm Status Change</h4>',
        'options' => [
            'class' => 'fade modal-confirmation',
            'tabindex' => '-1',
        ],
        'headerOptions' => [
            'class' => 'bg-primary text-white',
        ],
        'footerOptions' => [
            'class' => 'modal-footer-custom',
        ],
    ]);
    ?>

    <div id="modal-content" class="modal-body">
        <p>Are you sure you want to change the status?</p>
    </div>
    <div class="modal-footer">
        <?= Html::button('Cancel', ['class' => 'btn btn-secondary', 'data-bs-dismiss' => 'modal']) ?>
        <button type="button" id="confirm-btn" class="btn btn-primary">Confirm</button>
    </div>

    <?php Modal::end(); ?>

    <style>
    .custom-switch {
        display: flex;
        align-items: center;
    }

    .custom-switch .switch-input {
        position: relative;
        width: 50px;
        height: 25px;
        -webkit-appearance: none;
        background-color: red;
        outline: none;
        border-radius: 25px;
        transition: background-color 0.2s;
        cursor: pointer;
        margin: 0 10px;
    }

    .custom-switch .switch-input:checked {
        background-color: green;
    }

    .custom-switch .switch-input:before {
        content: '';
        position: absolute;
        width: 21px;
        height: 21px;
        border-radius: 50%;
        top: 2px;
        left: 2px;
        background-color: white;
        transition: transform 0.2s;
    }

    .custom-switch .switch-input:checked:before {
        transform: translateX(25px);
    }

    .switch-status-text {
        font-weight: bold;
        color: #495057;
        margin-left: 10px;
    }


    .form-group.text-center {
        margin-top: 20px;

    }

    .btn-success.btn-lg {
        padding: 10px 80px;

        font-size: 18px;

    }
</style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.switch-input').forEach(function(switchInput) {
                switchInput.addEventListener('change', function() {
                    const id = switchInput.getAttribute('data-id');
                    const statusText = document.getElementById('switch-status-text-' + id);
                    const newStatus = switchInput.checked ? 'Active' : 'Inactive';

                    const confirmation = confirm('Are you sure you want to change the status?');
                    if (!confirmation) {
                        // Revert the checkbox state if the user cancels
                        switchInput.checked = !switchInput.checked;
                        return;
                    }

                    statusText.textContent = switchInput.checked ? 'Active' : 'Inactive';

                    // Send AJAX request to update status
                    const url = switchInput.getAttribute('data-url');
                    fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-Token': yii.getCsrfToken()
                        },
                        body: JSON.stringify({
                            status: newStatus
                        })
                    }).then(response => {
                        if (response.ok) {
                            alert('Status updated successfully');
                        } else {
                            alert('Failed to update status');
                            switchInput.checked = !switchInput.checked;
                            statusText.textContent = switchInput.checked ? 'Active' : 'Inactive';
                        }
                    }).catch(error => {
                        alert('Error: ' + error);
                        // Revert the checkbox state if there is an error
                        switchInput.checked = !switchInput.checked;
                        statusText.textContent = switchInput.checked ? 'Active' : 'Inactive';
                    });
                });
            });
        });
    </script>

    <?php
    $this->registerCss("
    .modal-confirmation .modal-header {
        background-color: #007bff;
        color: #fff;
        border-bottom: 1px solid #007bff;
    }
    .modal-confirmation .modal-footer-custom {
        display: flex;
        justify-content: space-between;
        border-top: 1px solid #dee2e6;
    }
    .modal-confirmation .modal-footer-custom .btn {
        min-width: 100px;
    }
    .modal-confirmation .modal-body {
        text-align: center;
        font-size: 16px;
        padding: 20px;
    }
    .btn-long {
        width: 150px;
    }
");
    $this->registerJs("
    $('.toggle-status').on('click', function (e) {
        e.preventDefault();
        var url = $(this).data('url');
        $('#confirm-btn').data('url', url);
        $('#confirm-modal').modal('show');
    });

    $('#confirm-btn').on('click', function () {
        var url = $(this).data('url');
        $.post(url, function (result) {
            location.reload();
        });
    });
");
    ?>