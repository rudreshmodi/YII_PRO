<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var backend\models\Products $model */

$this->title = 'Create Products';
$this->params['breadcrumbs'][] = ['label' => 'Products', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>


<div class="products-create">
    <div class="flex w-full bg-gray-300 rounded">
        <div class="max-w-screen w-full px-4 py-4">
            <div class="mx-auto bg-gray-100 shadow-md rounded px-8 pt-4 pb-4">
                <h4><?= Html::encode($this->title) ?></h4>
                <hr class='h-1 bg-dark'>
                <?= $this->render('_form', [
                    'model' => $model,
                ]) ?>
            </div>
        </div>
    </div>
</div>