<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var backend\models\Products $model */

$this->title = 'Update Products: ' . $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Products', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->name, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<style>
    .custom-switch {
        display: flex;
        align-items: center;
    }

    .custom-switch .switch-input {
        position: relative;
        width: 50px;
        height: 25px;
        -webkit-appearance: none;
        background-color: #ddd;
        outline: none;
        border-radius: 25px;
        transition: background-color 0.2s;
        cursor: pointer;
        margin: 0 10px;
    }

    .custom-switch .switch-input:checked {
        background-color: #007bff;
    }

    .custom-switch .switch-input:before {
        content: '';
        position: absolute;
        width: 21px;
        height: 21px;
        border-radius: 50%;
        top: 2px;
        left: 2px;
        background-color: white;
        transition: transform 0.2s;
    }

    .custom-switch .switch-input:checked:before {
        transform: translateX(25px);
    }

    .switch-status-text {
        font-weight: bold;
        color: #495057;
        margin-left: 10px;
        margin-top: -45px;
    }


    .form-group.text-center {
        margin-top: 20px;
    }

    .btn-success.btn-lg {
        padding: 10px 80px;
        font-size: 18px;
    }

    .custom-switch .switch-input:checked {
        background-color: #28a745;
    }

    .switch-status-text {
        font-weight: bold;
        margin-left: 10px;
        color: #dc3545;

    }
</style>
<div class="products-form">
    <?php $form = ActiveForm::begin([
        'options' => ['class' => 'grid grid-cols-2 gap-4'],
        'fieldConfig' => [
            'options' => ['class' => 'mb-4'],
            'template' => "{label}\n{input}\n{error}",
            'labelOptions' => ['class' => 'text-sm font-bold text-gray-700'],
        ],
    ]); ?>

    <div class="mb-3 col-span-3">
        <?= Html::label('Name', 'products-name', ['class' => 'text-sm font-bold text-gray-700']) ?>
        <?= Html::activeTextInput($model, 'name', [
            'id' => 'products-name',
            'class' => 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
        ]) ?>
        <?= Html::error($model, 'name', ['class' => 'text-xs text-red-500']) ?>
    </div>

    <div class="mb-4">
        <?= Html::label('Category', 'products-category', ['class' => 'text-sm font-bold text-gray-700']) ?>
        <?= Html::activeTextInput($model, 'category', [
            'id' => 'products-category',
            'class' => 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
        ]) ?>
        <?= Html::error($model, 'category', ['class' => 'text-xs text-red-500']) ?>
    </div>

    <div class="mb-4">
        <?= Html::label('Price', 'products-price', ['class' => 'text-sm font-bold text-gray-700']) ?>
        <?= Html::activeTextInput($model, 'price', [
            'id' => 'products-price',
            'class' => 'pl-12 shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
            'placeholder' => 'Enter price...',
            'style' => 'padding-left: 2.5rem;',
        ]) ?>
        <?= Html::error($model, 'price', ['class' => 'text-xs text-red-500']) ?>
    </div>
    <div class="mb-2">
        <div class="form-group custom-switch mt-4">
            <?= $form->field($model, 'status')->checkbox([
                'label' => false,
                'class' => 'switch-input',
                'uncheck' => 'Inactive',
                'checked' => $model->status === 'Active',
                'id' => 'status-switch',
            ])->label(false); ?>
            <div class="mb-4">
                <div id="status-block" class="status-block p-1 pr-3">
                    <span id="switch-status-text" class="switch-status-text"><?= $model->status === 'Active' ? 'Active' : 'Inactive'; ?></span>
                </div>
            </div>

        </div>
    </div>
    <div class="mb-4 col-span-2">
        <?= Html::label('Description', 'products-description', ['class' => 'text-sm font-bold text-gray-700']) ?>
        <?= Html::activeTextarea($model, 'description', [
            'id' => 'products-description',
            'rows' => 6,
            'class' => 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline',
        ]) ?>
        <?= Html::error($model, 'description', ['class' => 'text-xs text-red-500']) ?>
    </div>
    <div class="mb-4">
    <?= Html::label('Current_Image', 'products-description', ['class' => 'text-sm font-bold text-gray-700']) ?>

    <?= Html::a(
        Html::img(Yii::$app->request->baseUrl . '/' . $model->image, [
            'class' => 'rounded-lg shadow-lg zoomable', // Add class 'zoomable'
            'style' => 'width: auto; max-height: 200px; object-fit: cover;',
        ]),
        ['update', 'id' => $model->id], // Replace with your actual parameters for update.php
        [
            'data-fancybox' => 'images',
            'data-caption' => Html::encode($model->name),
            'data-options' => '{"btnTpl": {"zoom": "<button data-fancybox-zoom class=\"fancybox-button fancybox-button--zoom\" title=\"Zoom\"><i class=\"fa fa-search-plus\"></i></button>"}}', // Enable zoom button
        ]
    ) ?>
</div>


    <div class="mb-4 col-span-3">
        <?= Html::label('Image', 'UserTest-image', ['class' => 'control-label text-sm font-bold text-gray-700']) ?>
        <div class="flex items-center justify-center border-2 border-dashed rounded-lg p-4 cursor-pointer">
            <div class="upload-icon">
                <h2 class="text-center"><i class="fas fa-cloud-upload-alt"></i></h2>
                <?= $form->field($model, 'imageFile', [
                    'template' => '{input}{label}{error}',
                    'inputOptions' => [
                        'class' => 'custom-file-input',
                        'id' => 'customFileInput',
                        'onchange' => 'showFileName(this); readURL(this);',
                    ],
                ])->fileInput(['class' => 'border btn btn-primary']) ?>
                <span id="file-name" class="upload-text">Click here or choose file to upload</span>
                <p id="file-size-error" class="help-block text-red-500" style="display:none;">File size exceeds 10MB limit.</p>
            </div>
            <img id="image-preview" class="hidden w-25 h-25" src="#" alt="Image Preview" />
        </div>
        <?= Html::error($model, 'imageFile', ['class' => 'text-xs text-red-500']) ?>
    </div>

  



    <div class="mb-4 col-span-2">
        <div class="col-span-2 flex">
            <?= Html::a('Cancel', ['index'], [
                'class' => 'bg-gray-300 hover:bg-gray-800 text-gray-800 font-bold py-2 px-4 mr-4 rounded focus:outline-none focus:shadow-outline',
                'style' => 'text-decoration: none;',
            ]) ?>
            <?= Html::submitButton('Save', ['class' => 'bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline']) ?>
        </div>

        <?php ActiveForm::end(); ?>
    </div>
</div>
<script>
      function showFileName(input) {
        var fileName = input.files[0].name;
        var span = document.getElementById('file-name');
        span.textContent = fileName;
    }


    document.getElementById('customFileInput').addEventListener('change', function() {
        var fileInput = this;
        var fileSize = fileInput.files[0].size;
        var maxSize = 10 * 1024 * 1024; // 10MB in bytes
        var fileSizeError = document.getElementById('file-size-error');

        if (fileSize > maxSize) {
            fileSizeError.style.display = 'block';
            fileInput.value = '';
            document.getElementById('file-name').textContent = 'Click here or choose file to upload';
        } else {
            fileSizeError.style.display = 'none';
        }
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image-preview').attr('src', e.target.result).removeClass('hidden');
            };
            reader.readAsDataURL(input.files[0]);
        }
    }


    document.addEventListener('DOMContentLoaded', function() {
        const statusSwitch = document.getElementById('status-switch');
        const statusText = document.getElementById('switch-status-text');


        statusText.textContent = statusSwitch.checked ? 'Active' : 'Inactive';
        statusText.style.color = statusSwitch.checked ? '#28a745' : '#dc3545';


        statusSwitch.addEventListener('change', function() {
            if (statusSwitch.checked) {
                statusText.textContent = 'Active';
                statusText.style.color = '#28a745';
            } else {
                statusText.textContent = 'Inactive';
                statusText.style.color = '#dc3545';
            }
        });
    });
</script>