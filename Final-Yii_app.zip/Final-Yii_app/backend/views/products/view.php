<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var backend\models\Products $model */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Products', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);

?>
<div class="products-view">
    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-2">
        <div class="flex items-center justify-between mb-4">
            <div>
            <h6 class="text-xl mb-2">
    <?= Html::a('<i class="fa-solid fa-arrow-left-long"></i>', ['index'], ['class' => 'mr-1 p-1 text-blue-800 font-bold rounded', 'style' => 'text-decoration: none;', 'id' => 'goBackLink']) ?>
    <?= Html::encode($this->title) ?>
</h6>

            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div class="bg-white shadow-lg rounded px-2 pt-2 pb-2 mb-2">
            <div class="flex items-center justify-content-center">
                <?= Html::a(
                    Html::img(Yii::$app->request->baseUrl . '/' . $model->image, [
                        'class' => 'rounded-lg shadow-lg zoomable', // Add class 'zoomable'
                        'style' => 'min-width: 400px; max-height: 400px; object-fit: cover;',
                    ]),
                    Yii::$app->request->baseUrl . '/' . $model->image,
                    [
                        'data-fancybox' => 'images',
                        'data-caption' => Html::encode($model->name),
                        'data-options' => '{"btnTpl": {"zoom": "<button data-fancybox-zoom class=\"fancybox-button fancybox-button--zoom\" title=\"Zoom\"><i class=\"fa fa-search-plus\"></i></button>"}}', // Enable zoom button
                    ]
                ) ?>
            </div>
        </div>

            <div>
                <?= DetailView::widget([
                    'model' => $model,
                    'options' => ['class' => 'table table-striped table-bordered border-10 detail-view rounded'],
                    'attributes' => [
                        'id',
                        'name',
                        'description:ntext',
                        'category',
                        'status',
                        'price',
                        'image'
                    ],
                ]) ?>
            </div>
        </div>

        <div class="text-center mt-4">
            <?= Html::a('<i class="fa-solid fa-pencil"></i> Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary px-4 m-1']) ?>
            <?= Html::a('<i class="fas fa-trash-alt"></i> Delete', ['delete', 'id' => $model->id], [
                'class' => 'btn btn-danger px-4 m-1',
                'data' => [
                    'confirm' => 'Are you sure you want to delete this item?',
                    'method' => 'post',
                ],
            ]) ?>
        </div>
    </div>
    <?php
    $this->registerJs("
    $('[data-fancybox=\"images\"]').fancybox({
        buttons: [
            'zoom',
            'slideShow',
            'thumbs',
            'close'
        ],
        loop: true,
        protect: true
    });
");
    ?>

</div>
<style>
    /* CSS for zoom effect */
    .zoomable:hover {
        cursor: zoom-out;
        transition: transform 0.3s ease-in;
    }

    .zoomable:active {
        transform: scale(1.2);
        /* Adjust the scale factor as needed */
        transition: transform 0.3s ease-in-out;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var goBackLink = document.getElementById('goBackLink');

        if (goBackLink) {
            goBackLink.addEventListener('click', function(event) {
                event.preventDefault(); 
                history.back(); 
            });
        }
    });
</script>
