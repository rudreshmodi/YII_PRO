<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var backend\models\RestaurantsSearch $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="restaurants-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
        'options' => [
            'class' => 'form-inline gap-2', // Bootstrap form inline class
        ],
    ]); ?>

    <div class="row flex border col-lg-12">
        <div class="form-gruop">
            <?= $form->field($model, 'RestaurantName')->textInput(['placeholder' => 'Restaurant Name'])->label(false) ?>

            <?= $form->field($model, 'City')->textInput(['placeholder' => 'City'])->label(false) ?>
        </div>

        <div class="form-gruop">
            <!-- <div class="form-group"> -->
            <?= Html::submitButton('Search', ['class' => 'btn btn-primary mr-2']) ?>
        </div>
        <div class="col-lg-3">
            <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>

        </div>
        <!-- </div> -->
    </div> 

    <?php ActiveForm::end(); ?>

</div>