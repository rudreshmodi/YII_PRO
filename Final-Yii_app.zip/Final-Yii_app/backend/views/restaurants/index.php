<?php

use backend\models\Restaurants;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/** @var yii\web\View $this */
/** @var backend\models\RestaurantsSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Restaurants';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="restaurants-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Restaurants', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); 
    ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        // 'filterModel' => $searchModel,
        'columns' => [
            // ['class' => 'yii\grid\SerialColumn'],

            'RestaurantID',
            'RestaurantName',
            'Address',
            'City',
            'State',
            'ZipCode',
            'Phone',
            'Email:email',
            'Website',
            'OpeningTime',
            'ClosingTime',
            'Description:ntext',
            [
                'attribute' => 'Rating',
                'value' => function ($model) {
                    $stars = '';
                    $rating = (float) $model->Rating;
                    $fullStars = floor($rating);
                    $halfStar = ceil($rating) > $fullStars ? true : false;

                    for ($i = 1; $i <= 5; $i++) {
                        if ($i <= $fullStars) {
                            $stars .= '<i class="star fas fa-star fa-2x" style="color: gold;"></i>';
                        } elseif ($halfStar && $i == ($fullStars + 1)) {
                            $stars .= '<i class="fas fa-star-half-alt fa-2x" style="color: gold; "></i>';
                        } else {
                            $stars .= '<i class="fas fa-star fa-2x" style="color: #ccc;"></i>';
                        }
                    }

                    return $stars;
                },
                'format' => 'raw',
            ],
            [
                'attribute' => 'CuisineType',
                'value' => function ($model) {
                    $cuisineTypes = explode(',', $model->CuisineType);
                    $tags = [];
                    foreach ($cuisineTypes as $cuisine) {
                        $tags[] = Html::tag('span', Html::encode(trim($cuisine)), ['class' => 'tag']);
                    }
                    return implode(' ', $tags);
                },
                'format' => 'raw',
            ],
            [
                'class' => ActionColumn::className(),
                'buttons' => [
                    'view' => function ($url, $model, $key) {
                        // return Html::a('<i class="fas fa-eye"></i>', $url, ['class' => 'btn btn-primary']);

                        return Html::a('<i class="fas fa-solid fa-eye"></i>', $url,['class' => 'btn btn-primary p-2'], [
                            'title' => Yii::t('yii', 'View'),
                        ]);
                    },
                    'update' => function ($url, $model, $key) {
                        return Html::a('<span class="action-btn"><i class="fas fa-pencil-alt"></i></span>', $url,['class' => 'btn btn-info p-2'], [
                            'title' => Yii::t('yii', 'Update'),
                        ]);
                    },
                    'delete' => function ($url, $model, $key) {
                        return Html::a('<span class="action-btn"><i class="fas fa-trash-alt"></i></span>', $url,['class' => 'btn btn-danger p-2'], [
                            'title' => Yii::t('yii', 'Delete'),
                            'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                            'data-method' => 'post',
                        ]);
                    },
                ],
                'urlCreator' => function ($action, $model, $key, $index) {
                    return Url::toRoute([$action, 'RestaurantID' => $model->RestaurantID]);
                },
            ],
            
        ],
    ]); ?>


</div>

<style>
    .star:hover {
        color: yellow;
    }

    .tag {
        display: inline-block;
        padding: 5px 10px;
        margin: 0 5px 5px 0;
        background-color: #ccc;
        /* Blue background color */
        color: #111;
        /* White text color */
        border-radius: 8px;
        /* Rounded borders */
        text-transform: capitalize;
        /* Capitalize text */
        text-decoration: none;
        /* Remove underline */
    }

    .tag:hover {
        background-color: #0056b3;
        /* Darker blue */
        cursor: pointer;
        color: #fff;
    }
</style>