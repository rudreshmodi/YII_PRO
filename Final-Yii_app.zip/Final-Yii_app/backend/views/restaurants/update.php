<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var backend\models\Restaurant $model */

$this->title = 'Update Restaurant: ' . $model->RestaurantID;
$this->params['breadcrumbs'][] = ['label' => 'Restaurants', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->RestaurantID, 'url' => ['view', 'RestaurantID' => $model->RestaurantID]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="Restaurant-update">
    <div class="flex w-full bg-gray-300 rounded">
        <div class="max-w-screen w-full px-4 py-4">
            <div class="mx-auto bg-gray-100 shadow-md rounded px-8 pt-4 pb-4">
                <h4><?= Html::encode($this->title) ?></h4>
                <hr class='h-1 bg-dark'>
                <?= $this->render('_form', [
                    'model' => $model,
                ]) ?>
            </div>
        </div>
    </div>
</div>