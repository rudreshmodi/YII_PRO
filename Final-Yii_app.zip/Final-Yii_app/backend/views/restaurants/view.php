<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var backend\models\Restaurants $model */

$this->title = $model->RestaurantName;
$this->params['breadcrumbs'][] = ['label' => 'Restaurants', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

\yii\web\YiiAsset::register($this);

?>

<div class="flex items-center justify-center h-full">
    <div class="bg-white shadow-md rounded px-8 py-6" style="width: 100%;">
        <div class="flex items-center justify-between">
        <h3 class="text-xl mb-2">
    <?= Html::a('<i class="fa-solid fa-arrow-left-long"></i>', ['index'], ['class' => 'mr-1 p-1 text-blue-800 font-bold rounded', 'style' => 'text-decoration: none;', 'id' => 'goBackLink']) ?>
    <?= Html::encode($this->title) ?>
</h3>
        </div>

        <?= DetailView::widget([
            'model' => $model,
            'options' => ['class' => 'table table-striped table-bordered detail-view rounded'],
            'attributes' => [
                'RestaurantName',
                'Address:ntext',
                'State',
                'City',
                'ZipCode',
                'Phone',
                'Email:email',
                'Website:url',
                'OpeningTime:time',
                'ClosingTime:time',
                'Description:ntext',
                [
                    'attribute' => 'Rating',
                    'value' => function ($model) {
                        $stars = '';
                        $rating = (float) $model->Rating;
                        $fullStars = floor($rating);
                        $halfStar = ceil($rating) > $fullStars ? true : false;

                        for ($i = 1; $i <= 5; $i++) {
                            if ($i <= $fullStars) {
                                $stars .= '<i class="star fas fa-star fa-2x" style="color: gold;"></i>';
                            } elseif ($halfStar && $i == ($fullStars + 1)) {
                                $stars .= '<i class="fas fa-star-half-alt fa-2x" style="color: gold; "></i>';
                            } else {
                                $stars .= '<i class="fas fa-star fa-2x" style="color: #ccc;"></i>';
                            }
                        }

                        return $stars;
                    },
                    'format' => 'raw',
                ],
                [
                    'attribute' => 'CuisineType',
                    'value' => function ($model) {
                        $cuisineTypes = explode(',', $model->CuisineType);
                        $tags = [];
                        foreach ($cuisineTypes as $cuisine) {
                            $tags[] = Html::tag('span', Html::encode(trim($cuisine)), ['class' => 'tag']);
                        }
                        return implode(' ', $tags);
                    },
                    'format' => 'raw',
                ],
            ],
        ]) ?>

        <div class="flex justify-center mt-4">
            <?= Html::a('<i class="fa-solid fa-pencil-alt"></i> Update', ['update', 'RestaurantID' => $model->RestaurantID], ['class' => 'btn btn-primary px-4 py-2 mr-2']) ?>
            <?= Html::a('<i class="fa-solid fa-trash-alt"></i> Delete', ['delete', 'RestaurantID' => $model->RestaurantID], [
                'class' => 'btn btn-danger px-4 py-2',
                'data' => [
                    'confirm' => 'Are you sure you want to delete this item?',
                    'method' => 'post',
                ],
            ]) ?>
        </div>
    </div>
</div>

<style>
    .star:hover {
        color: yellow;
    }

    .tag {
        display: inline-block;
        padding: 5px 10px;
        margin: 0 5px 5px 0;
        background-color: #ccc; /* Blue background color */
        color: #111; /* White text color */
        border-radius: 8px; /* Rounded borders */
        text-transform: capitalize; /* Capitalize text */
        text-decoration: none; /* Remove underline */
    }

    .tag:hover {
        background-color: #0056b3; /* Darker blue */
        cursor: pointer;
        color: #fff;
    }
</style>
