<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use backend\models\Restaurants;
use yii\helpers\Url;

/** @var yii\web\View $this */
/** @var backend\models\Restaurants $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="restaurants-form">

    <?php $form = ActiveForm::begin([
        'fieldConfig' => [
            'options' => ['class' => 'mb-4'], 
            'template' => "{label}\n{input}\n{error}", 
        ],
    ]); ?>

    <?= $form->field($model, 'RestaurantName')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'Address')->textarea(['rows' => 3, 'maxlength' => true]) ?>

    <div class="row">
        <div class=" form-group col-lg-5">
            <?= $form->field($model, 'State')->dropDownList([
                'Andhra Pradesh' => 'Andhra Pradesh',
                'Arunachal Pradesh' => 'Arunachal Pradesh',
                'Assam' => 'Assam',
                'Bihar' => 'Bihar',
                'Chhattisgarh' => 'Chhattisgarh',
                'Goa' => 'Goa',
                // Add more states as needed
            ], [
                'prompt' => 'Select State',
                'class' => 'form-control',
            ]) ?>
        </div>

        <div class="form-group col-lg-5">
            <?= $form->field($model, 'City')->dropDownList([
                'Mumbai' => 'Mumbai',
                'Delhi' => 'Delhi',
                'Bangalore' => 'Bangalore',
                'Kolkata' => 'Kolkata',
                'Chennai' => 'Chennai',
                'Hyderabad' => 'Hyderabad',
                // Add more cities as needed
            ], [
                'prompt' => 'Select City',
                'class' => 'form-control',
            ]) ?>
        </div>

        <div class="form-group col-lg-2">
            <?= $form->field($model, 'ZipCode')->textInput([
                'maxlength' => 6,
                'class' => 'form-control zip-input',
                'pattern' => '[0-9]{0,6}',
                'title' => 'Please enter up to 6 digits',
                'oninput' => 'this.value = this.value.replace(/[^0-9]/g, "").slice(0, 6)',
            ]) ?>
        </div>

        <div class="form-group col-lg-6">
            <?= $form->field($model, 'Phone')->textInput([
                'maxlength' => 13,
                'class' => 'form-control phone-input',
                'pattern' => '\+?\d{0,12}',
                'title' => 'Please enter up to 12 digits with optional + sign',
                'placeholder' => '+91 9876543210',
            ]) ?>
        </div>

        <div class="form-group col-lg-6">
            <?= $form->field($model, 'Email')->textInput(['maxlength' => true, 'class' => 'form-control']) ?>
        </div>

        <div class="form-group col-lg-6">
            <?= $form->field($model, 'Website')->textInput([
                'maxlength' => true,
                'class' => 'form-control custom-website-input',
                'placeholder' => 'Enter website URL',
            ]) ?>
        </div>

        <div class="form-group col-lg-3">
            <?= $form->field($model, 'OpeningTime')->textInput(['type' => 'time', 'class' => 'form-control']) ?>
        </div>

        <div class="form-group col-lg-3">
            <?= $form->field($model, 'ClosingTime')->textInput(['type' => 'time', 'class' => 'form-control']) ?>
        </div>

        <?= $form->field($model, 'Description')->textarea(['rows' => 6]) ?>

        <div class="form-group col-lg-4">
            <?= $form->field($model, 'Rating')->textInput(['type' => 'number', 'step' => '0.1', 'min' => 1.0, 'max' => 5.0, 'oninput' => 'validity.valid||(value=\'\')']) ?>
        </div>

        <div class="form-group col-lg-8">
            <div class="bg-gray-300 p-6 rounded-15 text-bg-light md-4">
            <?= $form->field($model, 'CuisineType')->checkboxList([
                'north_indian' => 'North Indian',
                'south_indian' => 'South Indian',
                'punjabi' => 'Punjabi',
                'gujarati' => 'Gujarati',
                'bengali' => 'Bengali',
                'hyderabadi' => 'Hyderabadi',
            ])->label('Cuisine Type')->hint('Select one or more') ?>
        </div>
        </div>
    </div>

    <div class="col-span-2 flex justify-end">
        <?= Html::a('Cancel', ['index'], ['class' => 'bg-gray-300 hover:bg-gray-800 text-gray-800 font-bold py-2 px-4 mr-4 rounded focus:outline-none focus:shadow-outline', 'style' => 'text-decoration: none;']) ?>
        <?= Html::submitButton($model->isNewRecord ? 'Save' : 'Update', [
    'class' => 'save bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline'
]) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
