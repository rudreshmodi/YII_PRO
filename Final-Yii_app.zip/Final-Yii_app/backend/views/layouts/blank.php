<?php

use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\bootstrap5\Alert;

/* @var $this yii\web\View */
/* @var $content string */

AppAsset::register($this);

$this->beginPage();
?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>

<body class="d-flex flex-column h-100">
<?php $this->beginBody() ?>

<?php
if (Yii::$app->session->hasFlash('success')) {
    echo Alert::widget([
        'options' => [
            'class' => 'alert alert-success alert-dismissible fade show', // Bootstrap classes for success alert
            'role' => 'alert',
        ],
        'body' => Yii::$app->session->getFlash('success'),
    ]);
}

// Display error flash messages
if (Yii::$app->session->hasFlash('error')) {
    echo Alert::widget([
        'options' => [
            'class' => 'alert alert-danger alert-dismissible fade show', // Bootstrap classes for error alert
            'role' => 'alert',
        ],
        'body' => Yii::$app->session->getFlash('error'),
    ]);
}
?>

<main role="main">
    <div class="container">
        <?= $content ?>
    </div>
</main>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>




<style>
    /* Success Alert */
.alert-success {
    color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;
}

/* Error Alert */
.alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
}

/* Close Button for Alerts */
.alert-dismissible .close {
    position: relative;
    top: -0.5rem;
    right: -1rem;
}

</style>
<script>
    // Script to remove flash message after 3 seconds
    setTimeout(function() {
        $('.alert').fadeOut('fast');
    }, 1000); // 3000 milliseconds = 3 seconds
</script>