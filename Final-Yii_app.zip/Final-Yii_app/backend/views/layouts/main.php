<?php

/** @var \yii\web\View $this */
/** @var string $content */

use backend\assets\AppAsset;
use common\widgets\Alert;
use yii\bootstrap5\Breadcrumbs;
use yii\bootstrap5\Html;
use yii\bootstrap5\NavBar;
use yii\helpers\Url;

AppAsset::register($this);
$this->registerCssFile('https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css');
$this->registerJsFile('https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);

if (Yii::$app->user->isGuest && !in_array(Yii::$app->controller->action->id, ['login'])) {
    Yii::$app->getResponse()->redirect(Url::to(['site/login']))->send();
    Yii::$app->end();
}
?>
<style>
html,
body {
    height: 100%;
}

#wrapper {
    display: flex;
}

#accordionSidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    height: 100%;
    /* overflow-y: auto; */
    z-index: 1;
    /* Ensure sidebar stays above content */
}

#content {
    flex: 1;
    overflow: auto;
    padding: 20px;
    width: 100%;
    z-index: 1;
    margin-left: 200px;
    /* Adjust based on sidebar width */
}


.top-alert {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;
}
</style>

<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" class="h-100 w-100">

<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>

<body class="flex flex-column h-100">
    <?php $this->beginBody() ?>
    <!-- Page Wrapper -->
    <div id="wrapper" class="d-flex" style="z-index: 99;">
        <!-- Top Alert -->
        <div class="top-alert">
            <?= Alert::widget() ?>
        </div>
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar"
            style="z-index: 99;">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= Yii::$app->homeUrl ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>

                <div class="sidebar-brand-text mx-3">Rudresh <sup>2.0</sup></div>

            </a>
            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->

            <!-- Divider -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= Yii::$app->homeUrl ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true"
                    aria-controls="collapseTwo">
                    <i class="fa-brands fa-product-hunt"></i> <span>Manage Products:</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Product Management:</h6>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['products/create']) ?>">Add
                            New Product</a>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['products/index']) ?>">View
                            Products</a>
                        <a class="collapse-item"
                            href="<?= Yii::$app->urlManager->createUrl(['products/all-products']) ?>">Card-view</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true"
                    aria-controls="collapseThree">
                    <i class="fa-solid fa-user"></i> <span>Manage Users:</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Users Management:</h6>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['users/create']) ?>">Add
                            New User</a>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['users/index']) ?>">View
                            Users</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true"
                    aria-controls="collapseFour">
                    <i class="fa-solid fa-graduation-cap"></i> <span>Manage Students:</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Student Management:</h6>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['student/create']) ?>">Add
                            New Student</a>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['student/index']) ?>">View
                            Students</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true"
                    aria-controls="collapseFive">
                    <i class="fa-brands fa-product-hunt"></i> <span>Manage Restaurants:</span>
                </a>
                <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Restaurants Management:</h6>
                        <a class="collapse-item"
                            href="<?= Yii::$app->urlManager->createUrl(['restaurants/create']) ?>">Add New
                            Restaurants</a>
                        <a class="collapse-item"
                            href="<?= Yii::$app->urlManager->createUrl(['restaurants/index']) ?>">View Restaurants</a>

                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="true"
                    aria-controls="collapseSix">
                    <i class="fa-solid fa-user"></i> <span>Manage User:</span>
                </a>
                <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">User Management:</h6>
                        <!-- <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['user/create']) ?>">Add New User</a> -->
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['user/index']) ?>">View
                            Users</a>
                    </div>
                </div>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider">
            <!-- Nav Item - Pages Collapse Menu -->
            <!-- <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Pages</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['site/login']) ?>">Login</a>
                        <?php if (Yii::$app->user->isGuest) : ?>
                            <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['site/signup']) ?>">Register</a>
                        <?php endif; ?>
                        <a class="collapse-item" href="<?= Yii::$app->urlManager->createUrl(['site/error']) ?>">404 Page</a>

                    </div>
                </div>
            </li> -->
        </ul>
        <!-- End of Sidebar -->


        <!-- Content Wrapper -->
        <div id="content" class="container-fluid">

            <!-- Topbar -->
            <?php

            NavBar::begin([
                'brandUrl' => Yii::$app->homeUrl,
                'options' => [
                    'class' => 'navbar navbar-expand-sm text-white topbar mb-4 fixed-top',
                    'style' => 'z-index:1; background-color:#f5f5f5'
                ],
            ]);
            ?>

            <!-- Sidebar Toggle (Topbar) -->
            <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                <i class="fas fa-bars"></i>
            </button>

            <!-- Topbar Search -->
            <form class="d-none d-sm-inline-block form-inline mr-auto ml-64 mt-2 mw-100 navbar-search">
                <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                        aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button">
                            <i class="fas fa-search fa-sm"></i>
                        </button>
                    </div>
                </div>
            </form>
            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">

                <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                <li class="nav-item dropdown no-arrow d-sm-none">
                    <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-search fa-fw"></i>
                    </a>
                    <!-- Dropdown - Messages -->
                    <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                        aria-labelledby="searchDropdown">
                        <form class="form-inline mr-auto w-100 navbar-search">
                            <div class="input-group">
                                <input type="text" class="form-control bg-light border-0 small"
                                    placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="button">
                                        <i class="fas fa-search fa-sm"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </li>

                <!-- Nav Item - Alerts -->
                <li class="nav-item dropdown no-arrow mx-1">
                    <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell fa-fw"></i>
                        <!-- Counter - Alerts -->
                        <span class="badge badge-danger badge-counter">3+</span>
                    </a>
                    <!-- Dropdown - Alerts -->
                    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                        aria-labelledby="alertsDropdown">
                        <h6 class="dropdown-header">
                            Alerts Center
                        </h6>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="mr-3">
                                <div class="icon-circle bg-primary">
                                    <i class="fas fa-file-alt text-white"></i>
                                </div>
                            </div>
                            <div>
                                <div class="small text-gray-500">December 12, 2019</div>
                                <span class="font-weight-bold">A new monthly report is ready to download!</span>
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="mr-3">
                                <div class="icon-circle bg-success">
                                    <i class="fas fa-donate text-white"></i>
                                </div>
                            </div>
                            <div>
                                <div class="small text-gray-500">December 7, 2019</div>
                                $290.29 has been deposited into your account!
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="mr-3">
                                <div class="icon-circle bg-warning">
                                    <i class="fas fa-exclamation-triangle text-white"></i>
                                </div>
                            </div>
                            <div>
                                <div class="small text-gray-500">December 2, 2019</div>
                                Spending Alert: We've noticed unusually high spending for your account.
                            </div>
                        </a>
                        <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                    </div>
                </li>

                <!-- Nav Item - Messages -->
                <li class="nav-item dropdown no-arrow mx-1">
                    <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-envelope fa-fw"></i>
                        <!-- Counter - Messages -->
                        <span class="badge badge-danger badge-counter">7</span>
                    </a>
                    <!-- Dropdown - Messages -->
                    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                        aria-labelledby="messagesDropdown">
                        <h6 class="dropdown-header">
                            Message Center
                        </h6>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://source.unsplash.com/fn_BT9fwg_E/60x60" alt="">
                                <div class="status-indicator bg-success"></div>
                            </div>
                            <div class="font-weight-bold">
                                <div class="text-truncate">Hi there! I am wondering if you can help me with a
                                    problem I've been having.</div>
                                <div class="small text-gray-500">Emily Fowler · 58m</div>
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://source.unsplash.com/AU4VPcFN4LE/60x60" alt="">
                                <div class="status-indicator"></div>
                            </div>
                            <div>
                                <div class="text-truncate">I have the photos that you ordered last month, how would
                                    you like them sent to you?</div>
                                <div class="small text-gray-500">Jae Chun · 1d</div>
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://source.unsplash.com/CS2uCrpNzJY/60x60" alt="">
                                <div class="status-indicator bg-warning"></div>
                            </div>
                            <div>
                                <div class="text-truncate">Last month's report looks great, I am very happy with
                                    the progress so far, keep up the good work!</div>
                                <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60" alt="">
                                <div class="status-indicator bg-success"></div>
                            </div>
                            <div>
                                <div class="text-truncate">Am I a good boy? The reason I ask is because someone
                                    told me that people say this to all dogs, even if they aren't good...</div>
                                <div class="small text-gray-500">Chicken the Dog · 2w</div>
                            </div>
                        </a>
                        <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                    </div>
                </li>

                <ul class="navbar-nav ml-50">
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small">Welcome,
                                <?= Yii::$app->user->isGuest ? 'Guest' : Yii::$app->user->identity->username ?>!</span>
                            <!-- <img class="img-profile rounded-circle" src="img/undraw_profile.svg"> -->
                            <img class="img-profile rounded-circle"
                                src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDI1LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IgoJIHZpZXdCb3g9IjAgMCAxMDguMyAxMDguMyIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMTA4LjMgMTA4LjM7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHN0eWxlIHR5cGU9InRleHQvY3NzIj4KCS5zdDB7ZmlsbDojRTZFNkU2O30KCS5zdDF7ZmlsbDojRkZCOEI4O30KCS5zdDJ7ZmlsbDojNTc1QTg5O30KCS5zdDN7ZmlsbDojMkYyRTQxO30KPC9zdHlsZT4KPGcgaWQ9Ikdyb3VwXzQ1IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMTkxIC0xNTIuMDc5KSI+Cgk8ZyBpZD0iR3JvdXBfMzAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDI4Mi4yNDYgMjI0LjM1MykiPgoJCTxwYXRoIGlkPSJQYXRoXzk0NCIgY2xhc3M9InN0MCIgZD0iTTE3LjEtMTguMWMwLDEwLjUtMywyMC44LTguOCwyOS42Yy0xLjIsMS45LTIuNSwzLjYtNCw1LjNjLTMuNCw0LTcuMyw3LjQtMTEuNiwxMC4zCgkJCWMtMS4yLDAuOC0yLjQsMS41LTMuNiwyLjJjLTYuNSwzLjYtMTMuNyw1LjgtMjEsNi41Yy0xLjcsMC4yLTMuNCwwLjItNS4xLDAuMmMtNC43LDAtOS40LTAuNi0xNC0xLjhjLTIuNi0wLjctNS4xLTEuNi03LjYtMi42CgkJCWMtMS4zLTAuNS0yLjUtMS4xLTMuNy0xLjhjLTIuOS0xLjUtNS42LTMuMy04LjItNS4zYy0xLjItMC45LTIuMy0xLjktMy40LTIuOUMtOTUuOCwxLjMtOTcuMS0zMy03Ni44LTU0LjlzNTQuNi0yMy4zLDc2LjUtMi45CgkJCUMxMC44LTQ3LjYsMTcuMS0zMy4yLDE3LjEtMTguMUwxNy4xLTE4LjF6Ii8+CgkJPHBhdGggaWQ9IlBhdGhfOTQ1IiBjbGFzcz0ic3QxIiBkPSJNLTUwLjItMTMuMmMwLDAsNC45LDEzLjcsMS4xLDIxLjRzNiwxNi40LDYsMTYuNHMyNS44LTEzLjEsMjIuNS0xOS43cy04LjgtMTUuMy03LjctMjAuOAoJCQlMLTUwLjItMTMuMnoiLz4KCQk8ZWxsaXBzZSBpZD0iRWxsaXBzZV8xODUiIGNsYXNzPSJzdDEiIGN4PSItNDAuNiIgY3k9Ii0yNS41IiByeD0iMTcuNSIgcnk9IjE3LjUiLz4KCQk8cGF0aCBpZD0iUGF0aF85NDYiIGNsYXNzPSJzdDIiIGQ9Ik0tNTEuMSwzNC4yYy0yLjYtMC43LTUuMS0xLjYtNy42LTIuNmwwLjUtMTMuM2w0LjktMTFjMS4xLDAuOSwyLjMsMS42LDMuNSwyLjMKCQkJYzAuMywwLjIsMC42LDAuMywwLjksMC41YzQuNiwyLjIsMTIuMiw0LjIsMTkuNS0xLjNjMi43LTIuMSw1LTQuNyw2LjctNy42TC04LjgsOWwwLjcsOC40bDAuOCw5LjhjLTEuMiwwLjgtMi40LDEuNS0zLjYsMi4yCgkJCWMtNi41LDMuNi0xMy43LDUuOC0yMSw2LjVjLTEuNywwLjItMy40LDAuMi01LjEsMC4yQy00MS44LDM2LjEtNDYuNSwzNS40LTUxLjEsMzQuMnoiLz4KCQk8cGF0aCBpZD0iUGF0aF85NDciIGNsYXNzPSJzdDIiIGQ9Ik0tNDcuNy0wLjlMLTQ3LjctMC45bC0wLjcsNy4ybC0wLjQsMy44bC0wLjUsNS42bC0xLjgsMTguNWMtMi42LTAuNy01LjEtMS42LTcuNi0yLjYKCQkJYy0xLjMtMC41LTIuNS0xLjEtMy43LTEuOGMtMi45LTEuNS01LjYtMy4zLTguMi01LjNsLTEuOS05bDAuMS0wLjFMLTQ3LjctMC45eiIvPgoJCTxwYXRoIGlkPSJQYXRoXzk0OCIgY2xhc3M9InN0MiIgZD0iTS0xMC45LDI5LjNjLTYuNSwzLjYtMTMuNyw1LjgtMjEsNi41YzAuNC02LjcsMS0xMy4xLDEuNi0xOC44YzAuMy0yLjksMC43LTUuNywxLjEtOC4yCgkJCWMxLjItOCwyLjUtMTMuNSwzLjQtMTQuMmw2LjEsNEw0LjksNy4zbC0wLjUsOS41Yy0zLjQsNC03LjMsNy40LTExLjYsMTAuM0MtOC41LDI3LjktOS43LDI4LjctMTAuOSwyOS4zeiIvPgoJCTxwYXRoIGlkPSJQYXRoXzk0OSIgY2xhc3M9InN0MiIgZD0iTS03MC41LDI0LjZjLTEuMi0wLjktMi4zLTEuOS0zLjQtMi45bDAuOS02LjFsMC43LTAuMWwzLjEtMC40bDYuOCwxNC44CgkJCUMtNjUuMiwyOC4zLTY3LjksMjYuNi03MC41LDI0LjZMLTcwLjUsMjQuNnoiLz4KCQk8cGF0aCBpZD0iUGF0aF85NTAiIGNsYXNzPSJzdDIiIGQ9Ik04LjMsMTEuNWMtMS4yLDEuOS0yLjUsMy42LTQsNS4zYy0zLjQsNC03LjMsNy40LTExLjYsMTAuM2MtMS4yLDAuOC0yLjQsMS41LTMuNiwyLjJsLTAuNi0yLjgKCQkJbDMuNS05LjFsNC4yLTExLjFsOC44LDEuMUM2LjEsOC43LDcuMiwxMC4xLDguMywxMS41eiIvPgoJCTxwYXRoIGlkPSJQYXRoXzk1MSIgY2xhc3M9InN0MyIgZD0iTS0yMy45LTQxLjRjLTIuNy00LjMtNi44LTcuNS0xMS42LTguOWwtMy42LDIuOWwxLjQtMy4zYy0xLjItMC4yLTIuMy0wLjItMy41LTAuMmwtMy4yLDQuMQoJCQlsMS4zLTRjLTUuNiwwLjctMTAuNywzLjctMTQsOC4zYy00LjEsNS45LTQuOCwxNC4xLTAuOCwyMGMxLjEtMy40LDIuNC02LjYsMy41LTkuOWMwLjksMC4xLDEuNywwLjEsMi42LDBsMS4zLTMuMWwwLjQsMwoJCQljNC4yLTAuNCwxMC4zLTEuMiwxNC4zLTEuOWwtMC40LTIuM2wyLjMsMS45YzEuMi0wLjMsMS45LTAuNSwxLjktMC43YzIuOSw0LjcsNS44LDcuNyw4LjgsMTIuNUMtMjIuMS0yOS44LTIwLjItMzUuMy0yMy45LTQxLjR6IgoJCQkvPgoJCTxlbGxpcHNlIGlkPSJFbGxpcHNlXzE4NiIgY2xhc3M9InN0MSIgY3g9Ii0yNC45IiBjeT0iLTI2LjEiIHJ4PSIxLjIiIHJ5PSIyLjQiLz4KCTwvZz4KPC9nPgo8L3N2Zz4K"
                                alt="" />
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                            aria-labelledby="userDropdown">

                            <a class="dropdown-item" href="<?= Yii::$app->urlManager->createUrl(['/site/profile']) ?>">
                                <i class="fas fa-user fa-sm fa-fw mr-2"></i> Profile
                            </a>

                            <a class="dropdown-item"
                                href="<?= Yii::$app->urlManager->createUrl(['/site/request-password-reset']) ?>">
                                <i class="fas fa-solid fa-lock fa-sm fa-fw mr-2"></i> Change Password
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?= Yii::$app->urlManager->createUrl(['/site/logout']) ?>"
                                data-toggle="modal" data-target="#logoutModal">
                                <?php
                                if (Yii::$app->user->isGuest) {
                                    echo Html::a('<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Login', ['/site/login'], ['class' => 'btn login d-flex text-decoration-none']);
                                } else {
                                    echo Html::beginForm(['/site/logout'], 'post', ['class' => 'p-0 m-0 d-flex'])
                                        . Html::submitButton('<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout', ['class' => 'btn p-0 m-0 logout text-center text-decoration-none', 'onclick' => 'return confirmLogout();'])
                                        . Html::endForm();
                                }
                                ?>
                            </a>
                        </div>
                    </li>
                </ul>

                <?php
                NavBar::end();

                ?>

                <!-- Main Content -->
                <main role="main" class="flex">
                    <div class="container">
                        <?= Breadcrumbs::widget([
                            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                        ]) ?>
                        <?= $content ?>
                    </div>
                </main>
                <!-- End of Main Content -->

                <!-- Footer -->
                <?php
                if (!Yii::$app->user->isGuest && !in_array(Yii::$app->controller->action->id, ['login', 'signup', 'profile', 'request-password-reset', 'reset-password'])) : ?>
                <footer class="footer py-3 text-muted">
                    <div class="container">
                        <p class="float-start">&copy; <?= Html::encode(Yii::$app->name) ?> <?= date('Y') ?></p>
                        <p class="float-end"><?= Yii::powered() ?></p>
                    </div>
                </footer>
                <?php endif; ?>
                <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->





    </div>
    <!-- End of Page Wrapper -->


    <?php $this->endBody() ?>
</body>

</html>
<?php $this->endPage(); ?>
<?php
if (Yii::$app->user->isGuest) {
    Yii::$app->getResponse()->redirect(Url::to(['site/login']))->send();
    Yii::$app->end();
}
?>
<script>
function confirmLogout() {
    document.getElementById('logout-form').submit();
}

function confirmLogout() {
    if (confirm('Are you sure you want to logout?')) {
        document.getElementById('logout-form').submit();
        return true;
    }
    return false;
}

// Script to remove flash message after 3 seconds
setTimeout(function() {
    $('.alert').fadeOut('fast');
}, 1500); // 3000 milliseconds = 3 seconds
</script>