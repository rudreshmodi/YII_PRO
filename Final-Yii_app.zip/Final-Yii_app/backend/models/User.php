<?php

namespace backend\models;

use Yii;
use frontend\models\ContactFormEntry;
use yii\web\NotFoundHttpException;

/**
 * This is the model class for table "{{%user}}".
 *
 * @property int $id
 * @property string $username
 * @property string $auth_key
 * @property string $password_hash
 * @property string|null $password_reset_token
 * @property string $email
 * @property string|null $role
 * @property int $status
 * @property int $created_at
 * @property int $updated_at
 * @property string|null $verification_token
 * @property string $phone
 * @property string|null $otp
 * @property int|null $otp_expire
 * @property string $created_otp
 *
 * @property ContactFormEntry[] $contactFormEntries
 */
class User extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%user}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'auth_key', 'password_hash', 'email', 'created_at', 'updated_at', 'phone'], 'required'],
            [['status', 'created_at', 'updated_at', 'otp_expire'], 'integer'],
            [['username', 'password_hash', 'password_reset_token', 'email', 'role', 'verification_token', 'phone', 'created_otp'], 'string', 'max' => 255],
            [['auth_key'], 'string', 'max' => 32],
            [['otp'], 'string', 'max' => 6],
            [['username'], 'unique'],
            [['email'], 'unique'],
            [['password_reset_token'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'auth_key' => 'Auth Key',
            'password_hash' => 'Password Hash',
            'password_reset_token' => 'Password Reset Token',
            'email' => 'Email',
            'role' => 'Role',
            'status' => 'Status',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'verification_token' => 'Verification Token',
            'phone' => 'Phone',
            'otp' => 'Otp',
            'otp_expire' => 'Otp Expire',
            'created_otp' => 'Created Otp',
        ];
    }

    /**
     * Gets query for [[ContactFormEntries]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getContactFormEntries()
    {
        return $this->hasMany(ContactFormEntry::class, ['user_id' => 'id']);
    }

    /**
     * @inheritdoc
     */
    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if ($this->isNewRecord || $this->isAttributeChanged('password_hash')) {
                $this->setPassword($this->password_hash); // Ensure to pass the current password_hash field
            }
            return true;
        }
        return false;
    }

    /**
     * Sets password hash
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password_hash = Yii::$app->security->generatePasswordHash($password);
    }
   
}
