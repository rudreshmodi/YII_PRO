<?php

namespace backend\models;

use common\models\User;
use Yii;
use yii\base\Model;

class OtpForm extends Model
{
    public $username;
    public $otp;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'otp'], 'required'],
            ['otp', 'integer'],
        ];
    }

    /**
     * Verifies OTP for a user.
     *
     * @return bool whether the OTP was verified successfully
     */
    public function verifyOtp()
    {
        $user = User::findOne(['username' => $this->username, 'otp' => $this->otp]);

        if ($user !== null) {
           // $user->otp = null; // Clear OTP once verified
            if ($user->save()) {
                return true;
            }
        }

        return false;
    }
}
