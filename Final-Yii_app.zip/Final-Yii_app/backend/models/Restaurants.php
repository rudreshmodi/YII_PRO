<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%Restaurants}}".
 *
 * @property int $RestaurantID
 * @property string $RestaurantName
 * @property string|null $Address
 * @property string|null $City
 * @property string|null $State
 * @property string|null $ZipCode
 * @property string|null $Phone
 * @property string|null $Email
 * @property string|null $Website
 * @property string|null $OpeningTime
 * @property string|null $ClosingTime
 * @property string|null $Description
 * @property string|null $Rating
 * @property string|null $CuisineType
 */
class Restaurants extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%Restaurants}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['RestaurantName', 'Email', 'Phone', 'Address', 'Rating', 'State', 'City', 'CuisineType', 'ZipCode', 'OpeningTime', 'ClosingTime', 'Description'], 'required'],
            [['RestaurantID'], 'integer'],
            [['OpeningTime', 'ClosingTime'], 'safe'],
            [['Description'], 'string'],
            [['Rating'], 'string'],
            [['RestaurantName', 'City', 'Email', 'CuisineType'], 'string', 'max' => 100],
            [['Address', 'Website'], 'string', 'max' => 255],
            [['State'], 'string', 'max' => 50],
            [['ZipCode', 'Phone'], 'string', 'max' => 20],
            [['RestaurantID'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'RestaurantID' => 'ID',
            'RestaurantName' => 'Restaurant Name',
            'Address' => 'Address',
            'City' => 'City',
            'State' => 'State',
            'ZipCode' => 'Zip Code',
            'Phone' => 'Phone',
            'Email' => 'Email',
            'Website' => 'Website',
            'OpeningTime' => 'Opening Time',
            'ClosingTime' => 'Closing Time',
            'Description' => 'Description',
            'Rating' => 'Rating',
            'CuisineType' => 'Cuisine Type',
        ];
    }
}
