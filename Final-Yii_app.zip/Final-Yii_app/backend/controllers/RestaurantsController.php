<?php

namespace backend\controllers;

use backend\models\Restaurants;
use backend\models\RestaurantsSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;

/**
 * RestaurantsController implements the CRUD actions for Restaurants model.
 */
class RestaurantsController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Restaurants models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new RestaurantsSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Restaurants model.
     * @param int $RestaurantID Restaurant ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($RestaurantID)
    {
        return $this->render('view', [
            'model' => $this->findModel($RestaurantID),
        ]);
    }

    /**
     * Creates a new Restaurants model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Restaurants();

        if ($this->request->isPost && $model->load($this->request->post())) {
            // Convert CuisineType array to string if it's an array
            if (is_array($model->CuisineType)) {
                $model->CuisineType = implode(',', $model->CuisineType);
            }

            // Validate and save model
            if ($model->validate() && $model->save()) {
                return $this->redirect(['view', 'RestaurantID' => $model->RestaurantID]);
            }
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Restaurants model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $RestaurantID Restaurant ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($RestaurantID)
    {
        $model = $this->findModel($RestaurantID);

        $model->CuisineType = explode(',', $model->CuisineType);

        if ($this->request->isPost && $model->load($this->request->post())) {
            $model->CuisineType = implode(',', $model->CuisineType);

            if ($model->validate() && $model->save()) {
                return $this->redirect(['view', 'RestaurantID' => $model->RestaurantID]);
            }
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }


    /**
     * Deletes an existing Restaurants model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $RestaurantID Restaurant ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($RestaurantID)
    {
        $this->findModel($RestaurantID)->delete();

        return $this->redirect(['index']);
    }

  

    /**
     * Finds the Restaurants model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $RestaurantID Restaurant ID
     * @return Restaurants the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($RestaurantID)
    {
        if (($model = Restaurants::findOne($RestaurantID)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
