<?php

namespace backend\controllers;

use backend\models\OtpForm;
use backend\models\PasswordResetRequestForm;
use backend\models\ResetPasswordForm;
use common\models\LoginForm;
use common\models\User;
use InvalidArgumentException;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use yii\filters\VerbFilter;
use yii\web\BadRequestHttpException;

/**
 * Site controller
 */
class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['login', 'error', 'verify-otp', 'request-password-reset', 'reset-password', 'logout', 'index', 'profile'],
                'rules' => [
                    [
                        'actions' => ['login', 'error', 'verify-otp', 'request-password-reset', 'reset-password'],
                        'allow' => true,
                    ],
                    [
                        'actions' => ['logout', 'index', 'profile'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => \yii\web\ErrorAction::class,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    /**
     * Login action.
     *
     * @return string|Response
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $this->layout = 'blank';

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            if (Yii::$app->user->identity->role !== 'admin') {
                Yii::$app->user->logout();
                Yii::$app->session->setFlash('error', 'You do not have admin credentials to log in.');
                return $this->redirect(['site/login']);
            }
            Yii::$app->session->setFlash('success', 'You have logged in successfully.');
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logs out the current user.
     *
     * @return mixed
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();
        Yii::$app->session->setFlash('success', 'You have been logged out successfully.');
        return $this->goHome();
    }

    /**
     * Requests password reset.
     *
     * @return mixed
     */
    public function actionRequestPasswordReset()
    {
        $model = new PasswordResetRequestForm();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($model->sendEmail()) {
                Yii::$app->session->setFlash('success', 'Check your email for further instructions.');
                return $this->goHome();
            }
            Yii::$app->session->setFlash('error', 'Sorry, we are unable to reset password for the provided email address.');
        }

        return $this->render('requestPasswordResetToken', [
            'model' => $model,
        ]);
    }

    /**
     * Resets password.
     *
     * @param string $token
     * @return mixed
     * @throws BadRequestHttpException
     */
    public function actionResetPassword($token)
    {
        try {
            $model = new ResetPasswordForm($token);
        } catch (InvalidArgumentException $e) {
            throw new BadRequestHttpException($e->getMessage());
        }

        if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {
            Yii::$app->session->setFlash('success', 'New password saved.');
            return $this->goHome();
        }

        return $this->render('resetPassword', [
            'model' => $model,
        ]);
    }


    /**
     * Verifies OTP entered by the user.
     *
     * @param string $username
     * @return string|Response
     */
    public function actionVerifyOtp($username)
    {
        $model = new OtpForm();
        $model->username = $username;

        if ($model->load(Yii::$app->request->post()) && $model->verifyOtp()) {
            Yii::$app->session->setFlash('success', 'OTP verified successfully. Please check your inbox for verification email.');
            return $this->redirect(['site/login']);
        }

        return $this->render('verify-otp', [
            'model' => $model,
        ]);
    }

    /**
     * Displays user profile.
     *
     * @return mixed
     * @throws NotFoundHttpException if the user is not found
     */
    public function actionProfile()
    {
        $model = User::findOne(Yii::$app->user->id);

        if (!$model) {
            throw new NotFoundHttpException('User not found.');
        }

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Profile updated successfully.');
            return $this->refresh();
        }

        return $this->render('profile', [
            'model' => $model,
        ]);
    }
}